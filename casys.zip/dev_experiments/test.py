from vispy import app, gloo
import numpy as np

class TestCanvas(app.Canvas):
    def __init__(self):
        super().__init__(keys='interactive', size=(400, 400), title='VisPy OK?')
        quad = np.array(
            [-1,-1,0,0,  1,-1,1,0,  -1,1,0,1,  -1,1,0,1,  1,-1,1,0,  1,1,1,1],
            dtype='f4')
        self.vbo = gloo.VertexBuffer(quad)
        self.prog = gloo.Program(
            vert='''
                #version 330 core
                in vec2 in_pos; in vec2 in_uv;
                void main() { gl_Position = vec4(in_pos,0,1); }
            ''',
            frag='''#version 330 core
                out vec4 FragColor;
                void main() { FragColor = vec4(0.0); }
            ''')
        self.show()
        app.Timer(1, connect=lambda ev: print('.'), start=True)  # heartbeat

    def on_draw(self, ev):      # draw black every frame
        gloo.clear(True)

if __name__ == '__main__':
    TestCanvas()
    app.run()                   # <--- blocks forever