import pathlib

file_path = pathlib.Path(__file__)

with open(file_path.parent/'shaders/bool_white_cells.glsl') as f:
    bool_white_shader = '\n'.join(f.readlines())

with open(file_path.parent/'shaders/bool_hsv_cells.glsl') as f:
    bool_hsv_shader = '\n'.join(f.readlines())

with open(file_path.parent/'shaders/u8_hsv_mapped_cells.glsl') as f:
    u8_hsv_mapped_shader = '\n'.join(f.readlines())

with open(file_path.parent/'shaders/u8_grayscale_mapped_cells.glsl') as f:
    u8_grayscale_mapped_shader = '\n'.join(f.readlines())

with open(file_path.parent/'shaders/direction_bitmask.glsl') as f:
    direction_bitmask_shader = '\n'.join(f.readlines())

with open(file_path.parent/'shaders/wire.glsl') as f:
    wire_shader = '\n'.join(f.readlines())

with open(file_path.parent/'shaders/float_hsv_mapped_cells.glsl') as f:
    float_hsv_shader = '\n'.join(f.readlines())

with open(file_path.parent/'shaders/float_hsv_lerp_mapped_cells.glsl') as f:
    float_hsv_lerp_shader = '\n'.join(f.readlines())