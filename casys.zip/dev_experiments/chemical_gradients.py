from os import path
import numpy as np
import numba as nb
from casys.config import CASYS_CONFIG
from casys import *
from casys.dsl.kernel_utils import k_get_pos, k_get_dims, k_get_const, k_get_timestamp, k_get_wr_idx, k_patch_op, step_func_split
from casys.logging import setup_logging
from direction_util import *
from rng_util import *

CASYS_CONFIG.debug_ast_origin_tracking = True
CASYS_CONFIG.debug_ast_timeline = True

setup_logging(verbose=True)

@cac_type
class rec_chem_source:
    chem_a_rate: cact_field[np.float32, float]

@cac_type
class rec_chemicals:
    """
     Holds different types of signaling chemicals and morphogens.
     Each field represents a chemical and the concentration of that chemical in each cell.
     At 0 the chemical isn't present
    """
    chem_a: cact_field[np.float32, float]

DIM = 2**6
DIMS = (DIM,DIM)

@ca_kernel
def chemicals_update_step(
    chemicals: rec_chemicals,
    chem_sources: rec_chem_source,
) -> None:
    x, y = k_get_pos()
    # rng_seed = rng_hash(x,y,k_get_timestamp())

    # moore_sum = k_patch_op('sum', chemicals.chem_a, x,y ,3,3,[
    #     [1,1,1],
    #     [1,0,1],
    #     [1,1,1],
    # ])

    chem_a = k_patch_op('sum', chemicals.chem_a,x,y,3,3,[
        [.05,.1,.05],
        [.1 ,.4,.1 ],
        [.05,.1,.05],
      ]
    ) * k_get_const(np.float32, 'decay')

    rate = chem_sources.chem_a_rate[x,y]
    if chem_a > (1-rate):
        chemicals.chem_a[x,y] = 1
        return 

    chemicals.chem_a[x,y] = chem_a + rate

    # chem_a = chemicals.chem_a[x,y]

    # rng_sum = chem_a
    # rng_count = 1
    
    # for shift in range(8):
    #     rng_seed = rng_chain(rng_seed)
    #     d_check = np.uint8(0b1 << rng_int(rng_seed,0,7))
    #     dc_x,dc_y = direction_to_vec(d_check) # type: ignore

    #     value = chemicals.chem_a[x+dc_x,y+dc_y]
    #     if value < chem_a or rng_int(rng_seed,0,1)==0:
    #         diff = np.abs(chem_a-value)
    #         rng_sum += value
    #         rng_count += 1

    # chemicals.chem_a[x,y] = np.round((rng_sum+moore_sum) / (8 + rng_count))

    # extra_direction = rng_int(rng_seed, 0, 7)
    # extra_direction = np.uint8(0b1 << extra_direction)

    # dc_x,dc_y = direction_to_vec(extra_direction) # type: ignore
    # dc_x,dc_y = x+dc_x,y+dc_y

    # avg = np.round((chemicals.chem_a[x,y] + chemicals.chem_a[dc_x,dc_y] + moore_sum) / (2))

    # chemicals.chem_a[x,y] = avg

    # rng_seed = rng_chain(rng_seed)

@ca_kernel
def chem_source_update_step(
    chem_sources: rec_chem_source,
    chemicals: rec_chemicals,
):
    x,y = k_get_pos()
    wri = k_get_wr_idx()

    chem_a = chemicals.chem_a[wri,x,y]
    rate = chem_sources.chem_a_rate[x,y]
    if chem_a > (1-rate):
        chemicals.chem_a[x,y] = 1
        return 

    chemicals.chem_a[x,y] = chem_a + rate

@ca_sys_step_func
def step_fn(
    chemicals: rec_chemicals,
    chem_sources: rec_chem_source,
) -> None:
    chemicals_update_step(chemicals, chem_sources)

class constants(CaSimConstants):
    dims = DIMS
    decay = 0.999

sim = CaSim.from_step_func(
    step_func=step_fn,
    sim_constants=constants
)

if __name__ == "__main__":
    import random
    import pathlib
    from casys.viz import Visualizer
    from casys.viz.gui.ui_model import UIModel

    
    sim_mgr = SimManager(sim,0.1,history_buffer_len=40)

    file_path = pathlib.Path(__file__)

    with open(file_path.parent/'shaders/bool_hsv_cells.glsl') as f:
        bool_hsv_shader = '\n'.join(f.readlines())

    with open(file_path.parent/'shaders/u8_grayscale_mapped_cells.glsl') as f:
        u8_grayscale_shader = '\n'.join(f.readlines())

    with open(file_path.parent/'shaders/u8_hsv_mapped_cells.glsl') as f:
        u8_hsv_shader = '\n'.join(f.readlines())
    with open(file_path.parent/'shaders/float_hsv_mapped_cells.glsl') as f:
        float_hsv_shader = '\n'.join(f.readlines())

    def add_chemical_a(pos_press: tuple[int,int], pos_release: tuple[int,int]):
        sim.edit_cells(sim.ld_idx, ((*pos_release,(('chemicals_chem_a',1),)),))

    def sub_chemical_source_rate(pos_press: tuple[int,int], pos_release: tuple[int,int]):
        sim.edit_cells(sim.ld_idx, ((*pos_release,(('chem_sources_chem_a_rate', max(0,sim.buffers['chem_sources_chem_a_rate'][sim.ld_idx,*pos_release] - 0.1)),)),))

    def add_chemical_source_rate(pos_press: tuple[int,int], pos_release: tuple[int,int]):
        sim.edit_cells(sim.ld_idx, ((*pos_release,(('chem_sources_chem_a_rate', sim.buffers['chem_sources_chem_a_rate'][sim.ld_idx,*pos_release] + 0.1),)),))

    uim = UIModel()

    def info_fld_simulation_time() -> str:
        return str(sim.timestamp)
    uim.add_info_field('Simulation timestep: ',info_fld_simulation_time)

    uim.register_tool('Add Chem A', add_chemical_a)
    uim.register_tool('Chem A rate +1', add_chemical_source_rate)
    uim.register_tool('Chem A rate -1', sub_chemical_source_rate)

    viz = Visualizer(
        sim_mgr,
        layers_cfg = [
            {
                'name':     'Chemical sources',
                'field':    'chem_sources_chem_a_rate',    
                'dtype':    np.float32,             
                'shader':   bool_hsv_shader,
                'shader_uniforms': (('u_hsv_color',(250/360,1,1)),),
                'visible':  True,
            },
            {
                'name':     'Chemical A',
                'field':    'chemicals_chem_a',    
                'dtype':    np.float32,             
                'shader':   float_hsv_shader,
                'visible':  True,
            },
        ],
        ui_model=uim,
        window_size = (800, 800),
    )

    viz.start()