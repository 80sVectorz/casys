import numpy as np
import random
import numba
from numba import njit
from casys import *
from casys.dsl.kernel_utils import k_get_pos, k_get_dims

# leader_cac: CAC that gets created by an axon to search for other neurons to connect to.
# The search works as a combination of random walk and gradient traversal based on a chemical CA with signaling chemicals.
# For now the search happens in multiple time step and ends when either a max distance is reached or a neuron is found.
# When the leader finds a neuron to connect to a wire is created based on the leader's trail.
# A connection is created at the end of the wire which links the wire to the neuron.
@cac_type
class rec_leader:
    active: cact_field[np.uint8, int]
    steps_left: cact_field[np.int32, int]
    next_direction: cact_field[np.uint8, int]
    channel: cact_field[np.uint8, int]

# leader_trail_cac: CAC that marks the trail left by a leader as it moves.
@cac_type
class rec_leader_trail:
    channel: cact_field[np.uint8, int]

@cac_type
class rec_viz:
    char: cact_field[np.str_, str] = ' ' # type: ignore

DIM = 2**9
DIMS = (DIM, DIM)
WIRE_CHANNEL_WIDTH = 8

# Converts a direction bitmask to a (dx, dy) tuple.
@njit
def direction_to_vec(direction: np.uint8) -> tuple[np.int8, np.int8]:
    if direction == 0b0000_0001:
        return 0, 1
    elif direction == 0b0000_0010:
        return 1, 1
    elif direction == 0b0000_0100:
        return 1, 0
    elif direction == 0b0000_1000:
        return 1, -1
    elif direction == 0b0001_0000:
        return 0, -1
    elif direction == 0b0010_0000:
        return -1, -1
    elif direction == 0b0100_0000:
        return -1, 0
    elif direction == 0b1000_0000:
        return -1, 1
    return 0, 0

# Rotates a direction bitmask by a given offset.
@njit
def rotate_direction(direction: np.uint8, offset: np.int8) -> np.uint8:
    current_shift = np.int8(np.log2(np.uint8(direction)))
    new_shift = np.uint8((np.int8(current_shift) + np.int8(offset)) % 8)
    return np.uint8(0b1 << new_shift)

# The main update kernel for leader movement and trail marking.
@ca_kernel
def leader_update_fn(
    leaders: rec_leader,
    trails: rec_leader_trail,
) -> None:
    x, y = k_get_pos()

    if not leaders.active:
        return 

    # Leave a trail
    trails.channel = leaders.channel

    # Move leader
    dx, dy = direction_to_vec(leaders.next_direction) # type: ignore
    nx, ny = x + dx, y + dy

    # Only move if the next cell is empty
    if not leaders.active[nx, ny]:
        # Spawn new leader in the next cell
        leaders.active[nx, ny] = 1
        leaders.steps_left[nx, ny] = leaders.steps_left - 1
        # Randomize direction
        random_offset = np.random.randint(-1, 2)
        leaders.next_direction[nx, ny] = rotate_direction(leaders.next_direction, random_offset) # type: ignore
        leaders.channel[nx, ny] = leaders.channel

    # Remove leader from current cell
    leaders.active[x,y] = 0
    leaders.steps_left[x,y] = 0
    leaders.next_direction[x,y] = 0
    leaders.channel[x,y] = 0


@ca_kernel
def viz_update_fn(
    leaders: rec_leader,
    trails: rec_leader_trail,
    viz_buffer: rec_viz,
):
    x, y = k_get_pos()
    if leaders.active:
        viz_buffer.char[x,y] = '█'
    elif trails.channel != 0:
        viz_buffer.char[x,y] = '░'
    else:
        viz_buffer.char[x,y] = ' '

# System step function, calls the leader update kernel.
@ca_sys_step_func
def step_fn(
    leaders: rec_leader,
    trails: rec_leader_trail,
    viz_buffer: rec_viz,
) -> None:
    leader_update_fn(leaders, trails)
    viz_update_fn(leaders, trails, viz_buffer)

# Define the CA system for leaders and trails.
leader_ca_system = CaSystem(
    step_fn=step_fn,
)

# Create the simulation object.
sim = CaSim(system=leader_ca_system, dims=DIMS)

def render_grid(sim: CaSim):
    viz_buffer = sim.buffers['viz_buffer_char'][sim.ld_idx,:,:].transpose(1,0)
    lines = ["".join(viz_buffer[i]) for i in range(sim.dims[1])]
    return "\n".join(lines)


if __name__ == '__main__':
    import time

    # Randomly seed some leaders
    n_random_cells = 10
    cell_edits = tuple(
        (
            random.randrange(0, DIMS[0]), random.randrange(0, DIMS[1]),
            (
                ('leaders_active', 1),
                ('leaders_steps_left', 100),
                ('leaders_next_direction', np.uint8(0b1 << random.randint(0, b=7))),
                ('leaders_channel', 0b01001),
            )
        ) for _ in range(n_random_cells)
    )

    sim.edit_cells( 0, cell_edits)

    n_steps = 10_000

    start = time.perf_counter()
    for i in range(n_steps):
        # time.sleep(0.1)
        sim.step()
        # frame = render_grid(sim)
        # print('\033[H' + frame)
        # print(frame.count('█'))
    end = time.perf_counter()

    duration = end - start
    print(f"  Total: {duration:.4f}s")
    print(f"  Avg/step: {(duration / (n_steps - 1)) * 1000:.3f}")