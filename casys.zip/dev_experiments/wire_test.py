from typing import Any
import numpy as np
import random
from numba import njit
from casys import *
from casys.dsl.kernel_utils import k_get_pos, k_get_dims, k_get_wr_idx, k_patch_op, k_get_timestamp, step_func_split, k_neighbor_mask
from rng_util import *
from dev_experiments.bit_op_utils import *

# leader_cac: CAC that gets created by an axon to search for other neurons to connect to.
# The search works as a combination of random walk and gradient traversal based on a chemical CA with signaling chemicals.
# For now the search happens in multiple time step and ends when either a max distance is reached or a neuron is found.
# When the leader finds a neuron to connect to a wire is created based on the leader's trail.
# A connection is created at the end of the wire which links the wire to the neuron.
@cac_type
class rec_leader:
    active: cact_field[np.uint8, int]
    next_direction: cact_field[np.uint8, int]
    steps_left: cact_field[np.uint16, int]
    channel: cact_field[np.uint8, int]
    cell_claimed_by: cact_field[np.uint8, int] # direction bit mask pointing to interested leaders

@cac_type
class rec_wire:
    direction_a_in: cact_field[np.uint8, int] # Wire's main input direction
    direction_a_out: cact_field[np.uint8, int] # Wire's main output direction
    direction_b_in: cact_field[np.uint8, int]
    direction_b_out: cact_field[np.uint8, int]
    spike_a: cact_field[np.uint8, int]
    spike_b: cact_field[np.uint8, int]

@cac_type
class rec_connection:
    charge: cact_field[np.uint8, int]
    active: cact_field[np.uint8, int]

# leader_trail_cac: CAC that marks the trail left by a leader as it moves.
@cac_type
class rec_leader_trail:
    channel: cact_field[np.uint8, int]
    next_direction: cact_field[np.uint8, int] # Direction of the next element in the trail
    prev_direction: cact_field[np.uint8, int] # Direction of the previous element in the trail

DIM = 2**9
DIMS = (DIM, DIM)
WIRE_CHANNEL_WIDTH = 8

# Converts a direction bitmask to a (dx, dy) tuple.
@njit
def direction_to_vec(direction: np.uint8) -> tuple[np.int8, np.int8]:
    if direction == 0b0000_0001:
        return 0, 1
    elif direction == 0b0000_0010:
        return 1, 1
    elif direction == 0b0000_0100:
        return 1, 0
    elif direction == 0b0000_1000:
        return 1, -1
    elif direction == 0b0001_0000:
        return 0, -1
    elif direction == 0b0010_0000:
        return -1, -1
    elif direction == 0b0100_0000:
        return -1, 0
    elif direction == 0b1000_0000:
        return -1, 1
    return 0, 0

def direction_to_str(direction: np.uint8 | int):
    return ('N','NE','E','SE','S','SW','W','NW')[int(np.log2(np.uint8(direction)))]

# Rotates a direction bitmask by a given offset.
@njit(inline='always')
def rotate_direction(direction: np.uint8 | int, offset: np.int8 | int) -> np.uint8:
    return rol8(np.uint8(direction), offset%8) # type: ignore

# The main update kernel for leader movement and trail marking.
@ca_kernel
def leader_update_step(
    leaders: rec_leader,
    trails: rec_leader_trail,
    connections: rec_connection,
    wires: rec_wire,
) -> None:
    timestamp = k_get_timestamp()
    x, y = k_get_pos()

    if not leaders.active:
        return 

    rng_seed = rng_hash(x,y,timestamp)
    channel = leaders.channel

    # Get next direction
    next_direction = leaders.next_direction[x,y]
    prev_direction = rotate_direction(next_direction, 4) # type: ignore
    dx, dy = direction_to_vec(next_direction) # type: ignore
    nx, ny = x + dx, y + dy

    claimed_by = leaders.cell_claimed_by[nx,ny]
    steps_left = leaders.steps_left - 1
    connection_check = connections.active[nx,ny]

    # Only move if the next cell is empty and undisputed
    if (
        leaders.active[nx, ny] | trails.channel[nx, ny] == 0 and
        connection_check == 0
        and (
            claimed_by == 0 or
            claimed_by == prev_direction # type: ignore
        )
        and (
            (wires.direction_a_in[x,y] == 0 and wires.direction_b_in[nx,ny] == 0) or
            (wires.direction_b_in[x,y] == 0 and wires.direction_a_in[nx,ny] == 0)
        )
    ):
        if steps_left > 0:
            current_direction = next_direction

            # Spawn new leader in the next cell
            leaders.active[nx, ny] = 1
            leaders.steps_left[nx,ny] = steps_left

            # Randomize direction
            random_offset = rng_int(rng_seed, -1, 1) # type: ignore
            next_direction = rotate_direction(current_direction, random_offset) # type: ignore

            # Leave a trail
            trails.next_direction[nx,ny] = next_direction
            trails.channel[nx,ny] = channel
            trails.prev_direction[nx,ny] = prev_direction


            leaders.next_direction[nx, ny] = next_direction
            leaders.channel[nx, ny] = channel
        else:
            rng_seed = rng_chain(rng_seed)
            if rng_int(rng_seed, 0,1) == 1:
                connections.active[x,y] = 1

    elif steps_left > 0 and connection_check == 0:
        rng_seed = rng_chain(rng_seed)
        next_direction = 0b1 << rng_int(rng_seed, 0,7)
        leaders.next_direction[x, y] = next_direction
        leaders.steps_left[x,y] = steps_left
        trails.channel[x,y] = channel
        if steps_left - 1 > 0:
            trails.next_direction[x,y] = next_direction
        return

    # Remove leader from current cell
    leaders.active[x,y] = 0
    leaders.next_direction[x,y] = 0
    leaders.steps_left[x,y] = 0
    leaders.channel[x,y] = 0

@ca_kernel
def claims_update_step(
    leaders: rec_leader,
):
    wr_idx = k_get_wr_idx()
    x, y = k_get_pos()

    n_neighbours = k_patch_op('sum',leaders.active[wr_idx], x,y, 3,3, [
        [1,1,1],
        [1,0,1],
        [1,1,1],
    ])
    if n_neighbours == 0:
        leaders.cell_claimed_by[x,y] = 0b0
        return

    leaders.cell_claimed_by[x,y] = k_neighbor_mask(
        x=x,y=y,d=(d:=0),
        expr=leaders.active[wr_idx, x,y] & 1 & (leaders.next_direction[wr_idx,x,y] == rotate_direction(d,4))
    )

@ca_kernel
def trail_update_step(
    trails: rec_leader_trail,
    leaders: rec_leader,
    connections: rec_connection,
    wires: rec_wire,
):
    x,y = k_get_pos()
    wri = k_get_wr_idx()
    channel = trails.channel[x,y]
    next_direction = trails.next_direction[x,y]
    if channel | next_direction == 0: return

    next_direction_flipped = rotate_direction(next_direction, 4)
    nx,ny = direction_to_vec(next_direction)
    nx,ny = x+nx, y+ny
    prev_direction = trails.prev_direction[x,y]

    if (
        not (trails.channel[nx,ny] == channel and trails.prev_direction[nx,ny] == next_direction_flipped)
        and leaders.channel[x,y] != channel 
        and leaders.channel[nx,ny] != channel 
    ) :
        if connections.active[nx,ny] != 0 or (wires.direction_a_out[nx,ny] | wires.direction_b_out[nx,ny]) & next_direction_flipped != 0:
            if wires.direction_a_in[x,y] == 0:
                wires.direction_a_in[x,y] = next_direction
                wires.direction_a_out[x,y] = prev_direction
            elif wires.direction_b_in[x,y] == 0:
                wires.direction_b_in[x,y] = next_direction
                wires.direction_b_out[x,y] = prev_direction

        trails.channel[x,y] = 0
        trails.next_direction[x,y] = 0
        trails.prev_direction[x,y] = 0
        return

    # if trails.channel[nx,ny] != channel or trails.prev_direction[wri,nx,ny] != next_direction_flipped:

    #     trails.channel[x,y] = 0
    #     trails.next_direction[x,y] = 0
    #     trails.prev_direction[x,y] = 0
    #     return
    

@ca_kernel
def wire_update_step(
    wires: rec_wire,
    connections: rec_connection
):
    x,y = k_get_pos()

    wires.spike_a[x,y] = 0
    wires.spike_b[x,y] = 0

    d_a_in = wires.direction_a_in[x,y]
    d_b_in = wires.direction_b_in[x,y]
    d_a_out = wires.direction_a_out[x,y]
    d_b_out = wires.direction_b_out[x,y]

    if (d_a_in | d_a_out | d_b_in | d_b_out) == 0: return

    if d_a_in != 0:
        dc_x,dc_y = direction_to_vec(d_a_in) # type: ignore
        dc_x,dc_y = x+dc_x,y+dc_y
        if wires.direction_a_out[dc_x,dc_y] | wires.direction_b_out[dc_x,dc_y] | connections.active[dc_x,dc_y] != 0:
            neighbor_spike_a = wires.spike_a[dc_x,dc_y]
            neighbor_spike_b = wires.spike_b[dc_x,dc_y]
            spike_check = ((wires.direction_a_out[dc_x,dc_y]*neighbor_spike_a) | (wires.direction_b_out[dc_x,dc_y]*neighbor_spike_b)) & rotate_direction(d_a_in,4) 
            
            wires.spike_a[x,y] = spike_check != 0
        else:
            wires.direction_a_in[x,y] = 0
            wires.direction_a_out[x,y] = 0

    if d_b_in != 0:
        dc_x,dc_y = direction_to_vec(d_b_in) # type: ignore
        dc_x,dc_y = x+dc_x,y+dc_y
        if wires.direction_a_out[dc_x,dc_y] | wires.direction_b_out[dc_x,dc_y] | connections.active[dc_x,dc_y] != 0:
            neighbor_spike_a = wires.spike_a[dc_x,dc_y]
            neighbor_spike_b = wires.spike_b[dc_x,dc_y]
            spike_check = ((wires.direction_a_out[dc_x,dc_y]*neighbor_spike_a) | (wires.direction_b_out[dc_x,dc_y]*neighbor_spike_b)) & rotate_direction(d_b_in,4)
            wires.spike_b[x,y] = spike_check != 0
        else:
            wires.direction_b_in[x,y] = 0
            wires.direction_b_out[x,y] = 0

@ca_kernel
def connection_update_step(
    connections: rec_connection,
    wires: rec_wire,
):
    x,y = k_get_pos()
    if connections.active[x,y] == 0: return

    rng_seed = rng_hash(x,y,k_get_timestamp())

    for shift in range(8):
        d_check = np.uint8(0b1 << shift)
        d_check_flipped = rotate_direction(d_check,4)

        dc_x,dc_y = direction_to_vec(d_check) # type: ignore
        dc_x,dc_y = x+dc_x,y+dc_y

        if wires.direction_a_in[dc_x,dc_y] == d_check_flipped:
            rng_seed = rng_chain(rng_seed)
            if rng_int(rng_seed,0,10) == 0:
                wires.spike_a[dc_x,dc_y] = 1
        if wires.direction_b_in[dc_x,dc_y] == d_check_flipped:
            rng_seed = rng_chain(rng_seed)
            if rng_int(rng_seed,0,10) == 0:
                wires.spike_b[dc_x,dc_y] = 1


@ca_sys_step_func
def step_fn(
    leaders: rec_leader,
    trails: rec_leader_trail,
    connections:rec_connection,
    wires: rec_wire,
) -> None:
    leader_update_step(leaders, trails, connections, wires)

    step_func_split()

    claims_update_step(leaders)
    trail_update_step(trails,leaders,connections, wires)
    wire_update_step(wires)

    step_func_split()

    connection_update_step(connections,wires)


leader_ca_system = CaSystem(
    step_fn=step_fn,
)

sim = CaSim(system=leader_ca_system, dims=DIMS)

if __name__ == '__main__':
    import pathlib
    from casys.viz import Visualizer
    from casys.viz.gui.ui_model import UIModel

    random.seed(0)

    def random_leader(steps_left = 15) -> tuple[tuple[str,Any],...]:
        return (
            ('leaders_active', 1),
            ('leaders_next_direction', np.uint8(0b1 << random.randint(0, b=7))),
            ('leaders_channel', np.uint8(random.randint(1,255))),
            ('leaders_steps_left', steps_left)
        )


    n_random_cells = 500
    cell_edits = tuple(
        (
            random.randrange(0, DIMS[0]), random.randrange(0, DIMS[1]), random_leader(steps_left=random.randint(15,400))
        ) for _ in range(n_random_cells)
    )
    channels = set([edit[2] for _,_,edit in cell_edits])
    print(f'#unique leaders: {len(channels)}')

    sim.edit_cells( 0, cell_edits)

    sim_mgr = SimManager(sim,0.1, history_buffer_len=20)

    file_path = pathlib.Path(__file__)

    with open(file_path.parent/'shaders/bool_white_cells.glsl') as f:
        bool_white_shader = '\n'.join(f.readlines())

    with open(file_path.parent/'shaders/bool_hsv_cells.glsl') as f:
        bool_hsv_shader = '\n'.join(f.readlines())

    with open(file_path.parent/'shaders/u8_hsv_mapped_cells.glsl') as f:
        u8_hsv_mapped_shader = '\n'.join(f.readlines())

    with open(file_path.parent/'shaders/u8_grayscale_mapped_cells.glsl') as f:
        u8_grayscale_mapped_shader = '\n'.join(f.readlines())

    with open(file_path.parent/'shaders/direction_bitmask.glsl') as f:
        direction_bitmask_shader = '\n'.join(f.readlines())

    with open(file_path.parent/'shaders/wire.glsl') as f:
        wire_shader = '\n'.join(f.readlines())

    uim = UIModel()

    def info_fld_simulation_time() -> str:
        return str(sim.timestamp)

    def info_fld_n_leaders() -> str:
        return str(np.count_nonzero(sim.buffers['leaders_active'][sim.ld_idx]))
    
    uim.add_info_field('Simulation timestep: ',info_fld_simulation_time)
    
    def i_processor_direction_value(val) -> str:
        if val == 0:
            return 'NO DIR'
        print(f'{np.uint8(val):#010b} ({direction_to_str(val)}) | 180 {(flipped:=np.uint8(rotate_direction(val, 4))):#010b} (({direction_to_str(flipped)}))')
        return ('N','NE','E','SE','S','SW','W','NW')[int(np.log2(val))]

    def i_processor_direction_bitmask_value(val) -> str:
        if val == 0:
            return 'NO DIR'

        res = []
        print(f'[{np.uint8(val):#010b}')

        for i in range(8):
            if val & (0b1 << i):
                res.append(('N','NE','E','SE','S','SW','W','NW')[i])
                print(f'\t{(v:=np.uint8(0b1 << i)):#010b} ({direction_to_str(v)}) | 180 {(flipped:=np.uint8(rotate_direction(v, 4))):#010b} (({direction_to_str(flipped)}))')
        print(f']')

        return ', '.join(res)

    def i_processor_binary(val) -> str:
        return f'{val:#010b}'
    
    def tool_spawn_leader(pos_press: tuple[int,int], pos_release: tuple[int,int]):
        sim.edit_cells(sim.ld_idx,( (*pos_release,random_leader()),))


    def tool_spike(pos_press: tuple[int,int], pos_release: tuple[int,int]):
        sim.edit_cells(sim.ld_idx,( (*pos_release,(('wires_spike_a',1),('wires_spike_b',1))),))
        sim.edit_cells(sim.wr_idx,( (*pos_release,(('wires_spike_a',1),('wires_spike_b',1))),))
    
    # viz.add_info_field(info_fld_n_leaders, '#active leaders')
    
    uim.register_inspect_processors(
        [
            'leaders_next_direction',
            'trails_prev_direction',
            'trails_next_direction',
            'wires_direction_a_in',
            'wires_direction_a_out',
            'wires_direction_b_in',
            'wires_direction_b_out',
        ],
    i_processor_direction_value
    )
    uim.register_inspect_processors(['leaders_cell_claimed_by'],i_processor_direction_bitmask_value)

    uim.register_tool('Spawn leader', tool_spawn_leader)
    uim.register_tool('Spike', tool_spike)

    viz = Visualizer(
        sim_manager=sim_mgr,
        layers_cfg = [
            {
                'name':     'Connections',
                'field':    'connections_active',    
                'dtype':    np.uint8,             
                'shader':   bool_hsv_shader,  
                'shader_uniforms': (('u_hsv_color',(0,0.0,0.7)),('u_border_radius', 0.0),),
                'visible':  True,
            },
            {
                'name':     'Leader channels',
                'field':    'leaders_channel',    
                'dtype':    np.uint8,             
                'shader':   u8_hsv_mapped_shader,  
                'shader_uniforms': (('u_border_radius', 0.6),('u_alpha',1.0),),
                'visible':  True,
            },
            {
                'name':     'leaders',
                'field':    'leaders_active',    
                'dtype':    np.uint8,             
                'shader':   bool_white_shader,  
                'shader_uniforms': (('u_border_radius', 0.4),),
                'visible':  True,
            },
            {
                'name':     'claimed by',
                'field':    'leaders_cell_claimed_by',    
                'dtype':    np.uint8,             
                'shader':   direction_bitmask_shader,
                'shader_uniforms': (
                    ('u_pointer_radius', 0.2),
                    ('u_pointer_offset', 0.8),
                    ('u_alpha', 1.0),
                    ),
                'visible':  True,
            },
            {
                'name':     'Trail directions',
                'field':    'trails_next_direction',    
                'dtype':    np.uint8,             
                'shader':   direction_bitmask_shader,
                'shader_uniforms': (
                    ('u_pointer_radius', 0.4),
                    ('u_pointer_offset', -0.2),
                    ('u_rotation_offset', 4),
                    ('u_alpha', 1.0),
                    ),
                'visible':  True,
            },

            {
                'name':     'Wire B spikes',
                'field':    'wires_spike_b',    
                'dtype':    np.uint8,             
                'shader':   bool_hsv_shader,  
                'shader_uniforms': (('u_hsv_color',(0, 80/100, 83/100)),('u_alpha', 0.6),('u_border_radius', 0.6)),
                'visible':  True,
            },
            {
                'name':     'wires B in',
                'field':    'wires_direction_b_in',    
                'dtype':    np.uint8,             
                'shader':   wire_shader,  
                'shader_uniforms': (('u_hsv_color',(0, 96/100, 70/100)),('u_alpha', 1.0), ('u_rotation_offset',0)),
                'visible':  True,
            },
            {
                'name':     'wires B out',
                'field':    'wires_direction_b_out',    
                'dtype':    np.uint8,             
                'shader':   wire_shader,  
                'shader_uniforms': (('u_hsv_color',(0, 96/100, 70/100)),('u_alpha', 1.0),),
                'visible':  True,
            },

            {
                'name':     'Wire A spikes',
                'field':    'wires_spike_a',    
                'dtype':    np.uint8,             
                'shader':   bool_hsv_shader,  
                'shader_uniforms': (('u_hsv_color',(248/360, 80/100, 83/100)),('u_alpha', 0.6),('u_border_radius', 0.6)),
                'visible':  True,
            },
            {
                'name':     'wires A in',
                'field':    'wires_direction_a_in',    
                'dtype':    np.uint8,             
                'shader':   wire_shader,  
                'shader_uniforms': (('u_hsv_color',(248/360, 96/100, 70/100)),('u_alpha', 1.0), ('u_rotation_offset',0)),
                'visible':  True,
            },
            {
                'name':     'wires A out',
                'field':    'wires_direction_a_out',    
                'dtype':    np.uint8,             
                'shader':   wire_shader,  
                'shader_uniforms': (('u_hsv_color',(248/360, 96/100, 70/100)),('u_alpha', 1.0),),
                'visible':  True,
            },


            {
                'name':     'trails',
                'field':    'trails_channel',    
                'dtype':    np.uint8,             
                'shader':   u8_hsv_mapped_shader,  
                'shader_uniforms': (('u_alpha', 1.0),),
                'visible':  True,
            },
        ],
        ui_model=uim,
        fps=60,
        window_size = (1920, 1080),
    )

    viz.start()