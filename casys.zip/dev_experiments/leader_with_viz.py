import numpy as np
import random
import numba
from numba import njit
from casys import *
from casys.dsl.kernel_utils import k_get_pos, k_get_dims, k_get_wr_idx, k_patch_op, k_get_timestamp, step_func_split, k_neighbor_mask
from rng_util import *
from dev_experiments.bit_op_utils import *

# leader_cac: CAC that gets created by an axon to search for other neurons to connect to.
# The search works as a combination of random walk and gradient traversal based on a chemical CA with signaling chemicals.
# For now the search happens in multiple time step and ends when either a max distance is reached or a neuron is found.
# When the leader finds a neuron to connect to a wire is created based on the leader's trail.
# A connection is created at the end of the wire which links the wire to the neuron.
@cac_type
class rec_leader:
    active: cact_field[np.uint8, int]
    next_direction: cact_field[np.uint8, int]
    channel: cact_field[np.uint8, int]

    cell_claimed_by: cact_field[np.uint8, int] # direction bit mask pointing to interested leaders

# leader_trail_cac: CAC that marks the trail left by a leader as it moves.
@cac_type
class rec_leader_trail:
    channel: cact_field[np.uint8, int]

DIM = 2**11
DIMS = (DIM, DIM)
WIRE_CHANNEL_WIDTH = 8

# Converts a direction bitmask to a (dx, dy) tuple.
@njit
def direction_to_vec(direction: np.uint8) -> tuple[np.int8, np.int8]:
    if direction == 0b0000_0001:
        return 0, 1
    elif direction == 0b0000_0010:
        return 1, 1
    elif direction == 0b0000_0100:
        return 1, 0
    elif direction == 0b0000_1000:
        return 1, -1
    elif direction == 0b0001_0000:
        return 0, -1
    elif direction == 0b0010_0000:
        return -1, -1
    elif direction == 0b0100_0000:
        return -1, 0
    elif direction == 0b1000_0000:
        return -1, 1
    return 0, 0

def direction_to_str(direction: np.uint8 | int):
    return ('N','NE','E','SE','S','SW','W','NW')[int(np.log2(np.uint8(direction)))]

# Rotates a direction bitmask by a given offset.
@njit(inline='always')
def rotate_direction(direction: np.uint8, offset: np.int8) -> np.uint8:
    return rol8(np.uint8(direction), offset%8) # type: ignore

# The main update kernel for leader movement and trail marking.
@ca_kernel
def leader_update_step(
    leaders: rec_leader,
    trails: rec_leader_trail,
) -> None:
    timestamp = k_get_timestamp()
    x, y = k_get_pos()

    if not leaders.active:
        return 

    rng_seed = rng_hash(x,y,timestamp)
    channel = leaders.channel

    # Get next direction
    next_direction = leaders.next_direction
    dx, dy = direction_to_vec(next_direction) # type: ignore
    nx, ny = x + dx, y + dy

    claimed_by = leaders.cell_claimed_by[nx,ny]

    # Only move if the next cell is empty and undisputed
    if (
        leaders.active[nx, ny] == 0
        and (
            claimed_by == 0
            or claimed_by == rotate_direction(next_direction, 4) # type: ignore
        )
    ):
        # Leave a trail
        trails.channel[nx,ny] = leaders.channel

        current_direction = next_direction
        # Spawn new leader in the next cell
        leaders.active[nx, ny] = 1
        # Randomize direction
        random_offset = rng_int(rng_seed, -1, 1) # type: ignore
        next_direction = rotate_direction(current_direction, random_offset) # type: ignore
        leaders.next_direction[nx, ny] = next_direction
        leaders.channel[nx, ny] = channel

        # Remove leader from current cell
        leaders.active[x,y] = 0
        leaders.next_direction[x,y] = 0
        leaders.channel[x,y] = 0
    else:
        rng_seed = rng_chain(rng_seed)
        next_direction = 0b1 << rng_int(rng_seed, 0,7)
        leaders.next_direction[x, y] = next_direction

@ca_kernel
def claims_update_step(
    leaders: rec_leader,
):
    wr_idx = k_get_wr_idx()
    x, y = k_get_pos()

    n_neighbours = k_patch_op('sum',leaders.active[wr_idx], x,y, 3,3, [
        [1,1,1],
        [1,0,1],
        [1,1,1],
    ])
    if n_neighbours == 0:
        leaders.cell_claimed_by[x,y] = 0b0
        return

    leaders.cell_claimed_by[x,y] = k_neighbor_mask(
        x=x,y=y,d=(d:=0),
        expr=leaders.active[wr_idx, x,y] & 1 & (leaders.next_direction[wr_idx,x,y] == rotate_direction(d,4))
    )

@ca_sys_step_func
def step_fn(
    leaders: rec_leader,
    trails: rec_leader_trail,
) -> None:
    leader_update_step(leaders, trails)
    step_func_split()
    claims_update_step(leaders)

leader_ca_system = CaSystem(
    step_fn=step_fn,
)

sim = CaSim(system=leader_ca_system, dims=DIMS)

if __name__ == '__main__':
    import pathlib
    from casys.viz import Visualizer

    random.seed(0)

    n_random_cells = 500
    cell_edits = tuple(
        (
            random.randrange(0, DIMS[0]), random.randrange(0, DIMS[1]),
            (
                ('leaders_active', 1),
                ('leaders_next_direction', np.uint8(0b1 << random.randint(0, b=7))),
                ('leaders_channel', np.uint8(random.randint(1,255))),
            )
        ) for _ in range(n_random_cells)
    )
    # channels = set([edit[2] for _,_,edit in cell_edits])
    # print(f'#unique leaders: {len(channels)}')

    sim.edit_cells( 0, cell_edits)

    sim_mgr = SimManager(sim,0.1, history_buffer_len=20)

    file_path = pathlib.Path(__file__)

    with open(file_path.parent/'shaders/bool_white_cells.glsl') as f:
        bool_white_shader = '\n'.join(f.readlines())

    with open(file_path.parent/'shaders/u8_hsv_mapped_cells.glsl') as f:
        u8_hsv_mapped_shader = '\n'.join(f.readlines())

    with open(file_path.parent/'shaders/direction_bitmask.glsl') as f:
        direction_bitmask_shader = '\n'.join(f.readlines())

    viz = Visualizer(
        sim_mgr,
        layers_cfg = [
            {
                'name':     'leader channels',
                'field':    'leaders_channel',    
                'dtype':    np.uint8,             
                'shader':   u8_hsv_mapped_shader,  
                'shader_uniforms': (('u_border_radius', 0.6),('u_alpha',1.0),),
                'visible':  True,
            },
            {
                'name':     'leaders',
                'field':    'leaders_active',    
                'dtype':    np.uint8,             
                'shader':   bool_white_shader,  
                'shader_uniforms': (('u_border_radius', 0.4),),
                'visible':  True,
            },
            {
                'name':     'claimed by',
                'field':    'leaders_cell_claimed_by',    
                'dtype':    np.uint8,             
                'shader':   direction_bitmask_shader,
                'shader_uniforms': (
                    ('u_pointer_radius', 0.2),
                    ('u_pointer_offset', 0.8),
                    ('u_alpha', 1.0),
                    ),
                'visible':  True,
            },
            {
                'name':     'trails',
                'field':    'trails_channel',    
                'dtype':    np.uint8,             
                'shader':   u8_hsv_mapped_shader,  
                'shader_uniforms': (('u_alpha', 1.0),),
                'visible':  True,
            },
        ],
        window_size = (1080, 1080),
        target_fps   = 60
    )

    def info_fld_n_leaders() -> str:
        return str(np.count_nonzero(sim.buffers['leaders_active'][sim.ld_idx]))
    
    def i_processor_direction_value(val) -> str:
        if val == 0:
            return 'NO DIR'
        print(f'{np.uint8(val):#010b} ({direction_to_str(val)}) | 180 {(flipped:=np.uint8(rotate_direction(val, 4))):#010b} (({direction_to_str(flipped)}))')
        return ('N','NE','E','SE','S','SW','W','NW')[int(np.log2(val))]

    def i_processor_direction_bitmask_value(val) -> str:
        if val == 0:
            return 'NO DIR'

        res = []
        print(f'[{np.uint8(val):#010b}')

        for i in range(8):
            if val & (0b1 << i):
                res.append(('N','NE','E','SE','S','SW','W','NW')[i])
                print(f'\t{(v:=np.uint8(0b1 << i)):#010b} ({direction_to_str(v)}) | 180 {(flipped:=np.uint8(rotate_direction(v, 4))):#010b} (({direction_to_str(flipped)}))')
        print(f']')

        return ', '.join(res)

    def i_processor_binary(val) -> str:
        return f'{val:#010b}'
    
    # viz.add_info_field(info_fld_n_leaders, '#active leaders')
    
    viz.register_inspect_processors(['leaders_next_direction'],i_processor_direction_value)
    viz.register_inspect_processors(['leaders_cell_claimed_by'],i_processor_direction_bitmask_value)

    viz.start()