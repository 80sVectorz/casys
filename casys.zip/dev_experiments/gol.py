import numpy as np
import numba as nb
from casys import *
from casys.core import dataclass
from casys.dsl.kernel_utils import k_get_pos, k_get_dims, k_get_const, k_patch_op
from rng_util import *
from dev_experiments.bit_op_utils import *

@_cac_type
class rec_gol:
    alive: cact_field[np.uint8, int]

@_cac_type
class rec_viz:
    char: cact_field[np.str_, str] = ' ' # type: ignore

DIM = 2**9
DIMS = (DIM,DIM)

@ca_kernel
def gol_update_fn(
    gol_cells: rec_gol,
) -> None:
    x, y = k_get_pos()

    last_state = gol_cells.alive
    pop_size = k_patch_op('sum', gol_cells.alive, x,y ,3,3, [
        [1,1,1],
        [1,0,1],
        [1,1,1],
    ])

    new_state = last_state

    if last_state == 1:
        if 2 <= pop_size <= 3:
            new_state = 1
        else:
            new_state = 0
    elif last_state == 0 and pop_size == 3:
        new_state = 1

    gol_cells.alive[x,y] = new_state

@ca_kernel
def viz_update_fn(
    gol_cells: rec_gol,
    viz_buffer: rec_viz
):
    x, y = k_get_pos()
    if gol_cells.alive:
        viz_buffer.char[x,y] = '█'
    else:
        viz_buffer.char[x,y] = ' '

@ca_sys_step_func
def step_fn(
    gol_cells: rec_gol,
    viz_buffer: rec_viz
) -> None:
    gol_update_fn(gol_cells)
    viz_update_fn(gol_cells, viz_buffer)

gol_ca_system = CaSystem(
    step_fn = step_fn,
)

@dataclass
class Consts:
    pass

sim = CaSim(
    system=gol_ca_system,
    dims = DIMS,
    consts=Consts()
)

def generate_edits(n_random: int):
    return tuple(
            (random.randrange(0, DIMS[0]), random.randrange(0, DIMS[1]), (("alive", True),))
            for _ in range(n_random)
        )

def render_grid(sim: CaSim):
    viz_buffer = sim.buffers['viz_buffer_char'][sim.ld_idx,:,:].transpose(1,0)
    lines = ["".join(viz_buffer[i]) for i in range(sim.dims[1])]
    return "\n".join(lines)

if __name__ == "__main__":
    import time, random
    n_random_cells = DIM**2 // 4
    cell_edits = tuple(
            (
                random.randrange(0,DIMS[0]), random.randrange(0,DIMS[1]),
                (
                    ('gol_cells_alive',True),
                    ('viz_buffer_char','█'),
                )
            ) for _ in range(n_random_cells)
        )
    
    # cell_edits = tuple(
    #     (i,i,
    #     (
    #         ('alive',True),
    #         ('char','█'),
    #     )) for i in range(10)
    # )

    sim.edit_cells(sim.ld_idx, cell_edits)

    sim.step()

    start = time.perf_counter()
    for _ in range(n_steps:=10000):
        sim.step()
    end = time.perf_counter()

    label = f'PARALLEL GOL: {DIM} x {DIM}'

    duration = end - start
    print(f"[{label}] {n_steps} steps")
    print(f"  Total: {duration:.4f}s")
    print(f"  Avg/step: {(duration / (n_steps-1)) * 1000:.3f} ms")
    # print(render_grid(sim))
    # for i in range(10000):
    #     time.sleep(0.5)
    #     sim.step()
    #     print('\033[H'+render_grid(sim))