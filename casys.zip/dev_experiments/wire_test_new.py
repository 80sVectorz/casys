from typing import Any
from numba.parfors.parfor import swap_functions_map
import numpy as np
import random
import numba
from numba import njit
from casys import *
from casys.dsl.kernel_utils import k_get_pos, k_get_dims, k_mark_pos, k_patch_op, k_get_timestamp, step_func_split, k_neighbor_mask, step_func_swap
from rng_util import *
from bit_op_utils import *
from casys.config import CASYS_CONFIG
from casys.logging import setup_logging

CASYS_CONFIG.debug_ast_timeline = True

# CASYS_CONFIG.debug_disable_jit = 'full'
CASYS_CONFIG.debug_dynsrc_mode = 'mirror'

setup_logging(verbose=False)

@cac_type
class Leader:
    channel: cact_field[np.uint8, int]

    intent_next_direction: cact_field[np.uint8, int]
    resolved_next_owner: cact_field[np.uint8, int]

    steps_left: cact_field[np.uint16, int]

@cac_type
class Wire:
    direction_a_in: cact_field[np.uint8, int] # Wire's main input direction
    direction_a_out: cact_field[np.uint8, int] # Wire's main output direction
    direction_b_in: cact_field[np.uint8, int]
    direction_b_out: cact_field[np.uint8, int]
    spike_a: cact_field[np.uint8, int]
    spike_b: cact_field[np.uint8, int]

@cac_type
class Connection:
    spike: cact_field[np.uint8, int]
    charge: cact_field[np.uint8, int]
    active: cact_field[np.uint8, int]

@cac_type
class Trail:
    channel: cact_field[np.uint8, int]

    # directions are relative to each cell.
    # t=1                  t=2
    # · · ·                · ·  · ·
    # · #→· <-- next dir   · #→←#→·
    #   ↓  <-- prev dir      ↓
    #   ↑                    ↑
    # · # ·                · #  · ·
    next_direction: cact_field[np.uint8, int] # Direction of the next element in the trail
    prev_direction: cact_field[np.uint8, int] # Direction of the previous element in the trail

DIM = 2**10
DIMS = (DIM, DIM)
WIRE_CHANNEL_WIDTH = 8

# Converts a direction bitmask to a (dx, dy) tuple.
@njit
def direction_to_vec(direction: np.uint8) -> tuple[np.int8, np.int8]:
    if direction == 0b0000_0001:
        return 0, 1
    elif direction == 0b0000_0010:
        return 1, 1
    elif direction == 0b0000_0100:
        return 1, 0
    elif direction == 0b0000_1000:
        return 1, -1
    elif direction == 0b0001_0000:
        return 0, -1
    elif direction == 0b0010_0000:
        return -1, -1
    elif direction == 0b0100_0000:
        return -1, 0
    elif direction == 0b1000_0000:
        return -1, 1
    return 0, 0

def direction_to_str(direction: np.uint8 | int):
    return ('N','NE','E','SE','S','SW','W','NW')[int(np.log2(np.uint8(direction)))]

# Rotates a direction bitmask by a given offset.
@njit(inline='always')
def rotate_direction(direction: np.uint8 | int, offset: np.int8 | int) -> np.uint8:
    return rol8(np.uint8(direction), offset%8) # type: ignore

# The main update kernel for leader movement and trail marking.
@ca_kernel
def leaders_move_step(
    leaders: Leader,
    trails: Trail,
    connections: Connection,
) -> None:
    timestamp = k_get_timestamp()
    x, y = k_get_pos()

    channel = leaders.channel
    next_owner_dir = leaders.resolved_next_owner
    if channel == 0 and next_owner_dir == 0: return
    
    rng_seed = rng_hash(x,y,timestamp)
    channel = leaders.channel

    if channel != 0:
        steps_left = leaders.steps_left
        if steps_left > 0:
            steps_left = leaders.steps_left - 1

            # Get next direction
            next_direction = leaders.intent_next_direction
            dx, dy = direction_to_vec(next_direction) # type: ignore

            nx, ny = x + dx, y + dy ; k_mark_pos()

            if leaders.resolved_next_owner[nx,ny] != rotate_direction(next_direction, 4): # type: ignore
                # Agent is stuck and cannot move. This means that this cell stays occupied
                next_direction = 0b1 << np.uint8(rng_int(rng_seed, 0,7))
                leaders.intent_next_direction[x, y] = next_direction
                leaders.steps_left[x,y] = steps_left

                trails.channel = channel
                trails.next_direction[x,y] = next_direction
                return

            trails.channel = channel
            trails.next_direction[x,y] = next_direction

        elif next_owner_dir == 0:
            # Agent died and no other cell wants to move here

            leaders.channel[x,y] = 0
            leaders.intent_next_direction[x,y] = 0

            rng_seed = rng_chain(rng_seed)
            if rng_int(rng_seed, 0,1) == 1:
                connections.active[x,y] = 1

            return

    if next_owner_dir and not connections.active:
        no_dx,no_dy = direction_to_vec(next_owner_dir) # type: ignore
        no_x,no_y = x+no_dx, y+no_dy ; k_mark_pos()

        new_steps_left = leaders.steps_left[no_x,no_y]

        if new_steps_left > 0:
            new_steps_left -= 1
            rng_seed = rng_chain(rng_seed)
            random_offset = rng_int(rng_seed, -1, 1) # type: ignore
            new_direction = rotate_direction(next_owner_dir, 4+random_offset) # type: ignore
            leaders.intent_next_direction[x,y] = new_direction
            trails.next_direction[x,y] = new_direction
        else:
            leaders.intent_next_direction[x,y] = 0

        new_channel = leaders.channel[no_x,no_y]
        leaders.channel[x,y] = new_channel
        leaders.steps_left[x,y] = new_steps_left

        trails.channel[x,y] = new_channel
        trails.prev_direction[x,y] = next_owner_dir
    else:
        leaders.channel[x,y] = 0
        leaders.intent_next_direction[x,y] = 0
        leaders.steps_left[x,y] = 0


@ca_kernel
def leader_claims_update_step(
    leaders: Leader,
    trails: Trail,
    wires: Wire,
):
    x, y = k_get_pos()
    timestamp = k_get_timestamp()

    winner = 0
    if (
        leaders.channel == 0
        and trails.channel==0
        and ( 
            (wires.direction_a_in[x,y] == 0) or
            (wires.direction_b_in[x,y] == 0)
        )
    ):
        rng_seed = rng_hash(x,y,timestamp)

        neighbors_interested = k_neighbor_mask(
            x=x,y=y,d=(d:=0),
            expr=(
                    (leaders.channel[x,y]>0 and leaders.steps_left[x,y]>0)
                    and (leaders.intent_next_direction[x,y] == rotate_direction(d,4))
                )
        )

        if neighbors_interested != 0:
            check_dir = np.uint8(rng_int(rng_seed, 0,7))
            while winner == 0:
                check_dir += 1
                if check_dir > 7:
                    check_dir = 0
                winner = neighbors_interested & (0b1 << check_dir)

    leaders.resolved_next_owner[x,y] = winner

@ca_kernel
def trails_update_step(
    trails: Trail,
    leaders: Leader,
    connections: Connection,
    wires: Wire,
):
    x,y = k_get_pos()

    channel = trails.channel[x,y]
    next_direction = trails.next_direction[x,y]
    if channel | next_direction == 0: return

    next_direction_flipped = rotate_direction(next_direction, 4)
    n_dx,n_dy = direction_to_vec(next_direction) # type: ignore
    nx,ny = x+n_dx, y+n_dy ; k_mark_pos()

    prev_direction = trails.prev_direction[x,y]

    if (
        not (trails.channel[nx,ny] == channel and trails.prev_direction[nx,ny] == next_direction_flipped)
        and leaders.channel[x,y] != channel 
        and leaders.channel[nx,ny] != channel 
    ) :
        if connections.active[nx,ny] != 0 or (wires.direction_a_in[nx,ny] | wires.direction_b_in[nx,ny]) & next_direction_flipped != 0:
            if wires.direction_a_in[x,y] == 0:
                wires.direction_a_in[x,y] = next_direction
                wires.direction_a_out[x,y] = prev_direction
            elif wires.direction_b_in[x,y] == 0:
                wires.direction_b_in[x,y] = next_direction
                wires.direction_b_out[x,y] = prev_direction

        trails.channel[x,y] = 0
        trails.next_direction[x,y] = 0
        trails.prev_direction[x,y] = 0
        return

@ca_kernel
def connection_update_step(
    connections: Connection
    
):
    x,y = k_get_pos()
    if connections.active[x,y] == 0: return

    rng_seed = rng_hash(x,y,k_get_timestamp())

    if rng_int(rng_seed,0,10) == 0:
        connections.spike[x,y] = 1

@ca_kernel
def spikes_update_step(
    wires: Wire,
    connections: Connection
):
    x,y = k_get_pos()

    connections.spike[x,y] = 0
    wires.spike_a[x,y] = 0
    wires.spike_b[x,y] = 0

    d_a_in = wires.direction_a_in[x,y]
    d_b_in = wires.direction_b_in[x,y]
    d_a_out = wires.direction_a_out[x,y]
    d_b_out = wires.direction_b_out[x,y]

    if (d_a_in | d_a_out | d_b_in | d_b_out) == 0: return

    dc_x,dc_y = x,y ; k_mark_pos()

    if d_a_in != 0:
        dc_dx,dc_dy = direction_to_vec(d_a_in) # type: ignore
        dc_x,dc_y = x+dc_dx,y+dc_dy
        connection_spike = connections.spike[dc_x,dc_y] & connections.active[dc_x,dc_y]
        if connection_spike:
            wires.spike_a[x,y] = 1
        elif wires.direction_a_out[dc_x,dc_y] | wires.direction_b_out[dc_x,dc_y] | connections.active[dc_x,dc_y] != 0:
            neighbor_spike_a = wires.spike_a[dc_x,dc_y]
            neighbor_spike_b = wires.spike_b[dc_x,dc_y]
            spike_check = ((wires.direction_a_out[dc_x,dc_y]*neighbor_spike_a) | (wires.direction_b_out[dc_x,dc_y]*neighbor_spike_b)) & rotate_direction(d_a_in,4) 
            
            wires.spike_a[x,y] = spike_check != 0
        else:
            wires.direction_a_in[x,y] = 0
            wires.direction_a_out[x,y] = 0

    if d_b_in != 0:
        dc_dx,dc_dy = direction_to_vec(d_b_in) # type: ignore
        dc_x,dc_y = x+dc_dx,y+dc_dy
        connection_spike = connections.spike[dc_x,dc_y] & connections.active[dc_x,dc_y]
        if connection_spike:
            wires.spike_b[x,y] = 1
        elif wires.direction_a_out[dc_x,dc_y] | wires.direction_b_out[dc_x,dc_y] | connections.active[dc_x,dc_y] != 0:
            neighbor_spike_a = wires.spike_a[dc_x,dc_y]
            neighbor_spike_b = wires.spike_b[dc_x,dc_y]
            spike_check = ((wires.direction_a_out[dc_x,dc_y]*neighbor_spike_a) | (wires.direction_b_out[dc_x,dc_y]*neighbor_spike_b)) & rotate_direction(d_b_in,4)
            wires.spike_b[x,y] = spike_check != 0
        else:
            wires.direction_b_in[x,y] = 0
            wires.direction_b_out[x,y] = 0

@ca_sys_step_func
def step_fn(
    leaders: Leader,
    trails: Trail,
    connections: Connection,
    wires: Wire,
) -> None:
    spikes_update_step(wires,connections)
    connection_update_step(connections)

    leaders_move_step(leaders,trails, connections)
    trails_update_step(trails,leaders,connections,wires)

    step_func_split()
    step_func_swap([leaders])

    leader_claims_update_step(leaders, trails, wires)


# leader_ca_system = CASystem(
#     step_fn=step_fn,
# )
class constants(DefaultCaSimConstants):
    dims = DIMS

sim = CaSim.from_step_func(step_fn, constants)

if __name__ == '__main__':
    import pathlib
    from casys.viz import Visualizer
    from casys.viz.gui.ui_model import UIModel


    random.seed(0)

    def random_leader(steps_left = 15) -> tuple[tuple[str,Any],...]:
        return (
            ('leaders_intent_next_direction', np.uint8(0b1 << random.randint(0, b=7))),
            ('leaders_channel', np.uint8(random.randint(1,255))),
            ('leaders_steps_left', steps_left)
        )

    n_random_cells = 500
    cell_edits = tuple(
        (
            random.randrange(0, DIMS[0]), random.randrange(0, DIMS[1]), random_leader(steps_left=random.randint(15,400))

        ) for _ in range(n_random_cells)
    )
    channels = set([edit[2] for _,_,edit in cell_edits])
    print(f'#unique leaders: {len(channels)}')

    sim.edit_cells(  cell_edits)

    sim_mgr = SimManager(sim,0.1, history_buffer_len=20)

    file_path = pathlib.Path(__file__)

    with open(file_path.parent/'shaders/bool_white_cells.glsl') as f:
        bool_white_shader = '\n'.join(f.readlines())

    with open(file_path.parent/'shaders/bool_hsv_cells.glsl') as f:
        bool_hsv_shader = '\n'.join(f.readlines())

    with open(file_path.parent/'shaders/u8_hsv_mapped_cells.glsl') as f:
        u8_hsv_mapped_shader = '\n'.join(f.readlines())

    with open(file_path.parent/'shaders/u8_grayscale_mapped_cells.glsl') as f:
        u8_grayscale_mapped_shader = '\n'.join(f.readlines())

    with open(file_path.parent/'shaders/direction_bitmask.glsl') as f:
        direction_bitmask_shader = '\n'.join(f.readlines())

    with open(file_path.parent/'shaders/wire.glsl') as f:
        wire_shader = '\n'.join(f.readlines())

    uim = UIModel()

    def info_fld_simulation_time() -> str:
        return str(sim.timestamp)

    def info_fld_simulation_performance() -> str:
        fps = sim_mgr.fps_ema or sim_mgr.fps_avg or 0
        ms = sim_mgr.last_step_ms or 0
        return str(f'FPS ~ {fps:.1f} (step {ms:.2f} ms)')
    
    uim.add_info_field('Sim Timestep: ',info_fld_simulation_time)
    uim.add_info_field('Sim Performance: ',info_fld_simulation_performance)
    
    def i_processor_direction_value(val) -> str:
        if val == 0:
            return 'NO DIR'
        print(f'{np.uint8(val):#010b} ({direction_to_str(val)}) | 180 {(flipped:=np.uint8(rotate_direction(val, 4))):#010b} (({direction_to_str(flipped)}))')
        return ('N','NE','E','SE','S','SW','W','NW')[int(np.log2(val))]

    def i_processor_direction_bitmask_value(val) -> str:
        if val == 0:
            return 'NO DIR'

        res = []
        print(f'[{np.uint8(val):#010b}')

        for i in range(8):
            if val & (0b1 << i):
                res.append(('N','NE','E','SE','S','SW','W','NW')[i])
                print(f'\t{(v:=np.uint8(0b1 << i)):#010b} ({direction_to_str(v)}) | 180 {(flipped:=np.uint8(rotate_direction(v, 4))):#010b} (({direction_to_str(flipped)}))')
        print(f']')

        return ', '.join(res)

    def i_processor_binary(val) -> str:
        return f'{val:#010b}'
    
    def tool_spawn_leader(pos_press: tuple[int,int], pos_release: tuple[int,int]):
        sim.edit_cells(( (*pos_release,random_leader()),))


    def tool_spike(pos_press: tuple[int,int], pos_release: tuple[int,int]):
        sim.edit_cells(( (*pos_release,(('wires_spike_a',1),('wires_spike_b',1))),))
        sim.edit_cells(( (*pos_release,(('wires_spike_a',1),('wires_spike_b',1))),))
    
    # viz.add_info_field(info_fld_n_leaders, '#active leaders')
    
    uim.register_inspect_processors(
        [
            'leaders_intent_next_direction',
            'leaders_intent_next_direction',
            'trails_prev_direction',
            'trails_next_direction',
            'wires_direction_a_in',
            'wires_direction_a_out',
            'wires_direction_b_in',
            'wires_direction_b_out',
        ],
    i_processor_direction_value
    )
    uim.register_inspect_processors(['leaders_cell_claimed_by'],i_processor_direction_bitmask_value)

    uim.register_tool('Spawn leader', tool_spawn_leader)
    uim.register_tool('Spike', tool_spike)

    viz = Visualizer(
        sim_manager=sim_mgr,
        layers_cfg = [
            {
                'name':     'Connections',
                'field':    'connections_active',    
                'dtype':    np.uint8,             
                'shader':   bool_hsv_shader,  
                'shader_uniforms': (('u_hsv_color',(0,0.0,0.7)),('u_border_radius', 0.0),),
                'visible':  True,
            },
            {
                'name':     'Leader channels',
                'field':    'leaders_channel',    
                'dtype':    np.uint8,             
                'shader':   u8_hsv_mapped_shader,  
                'shader_uniforms': (('u_border_radius', 0.6),('u_alpha',1.0),),
                'visible':  True,
            },
            {
                'name':     'leaders',
                'field':    'leaders_channel',    
                'dtype':    np.uint8,             
                'shader':   bool_white_shader,  
                'shader_uniforms': (('u_border_radius', 0.4),),
                'visible':  True,
            },
            {
                'name':     'Trail directions',
                'field':    'trails_next_direction',    
                'dtype':    np.uint8,             
                'shader':   direction_bitmask_shader,
                'shader_uniforms': (
                    ('u_pointer_radius', 0.4),
                    ('u_pointer_offset', -0.2),
                    ('u_rotation_offset', 4.0),
                    ('u_alpha', 1.0),
                    ),
                'visible':  True,
            },

            {
                'name':     'Wire B spikes',
                'field':    'wires_spike_b',    
                'dtype':    np.uint8,             
                'shader':   bool_hsv_shader,  
                'shader_uniforms': (('u_hsv_color',(0, 80/100, 83/100)),('u_alpha', 0.6),('u_border_radius', 0.6)),
                'visible':  True,
            },
            {
                'name':     'wires B in',
                'field':    'wires_direction_b_in',    
                'dtype':    np.uint8,             
                'shader':   wire_shader,  
                'shader_uniforms': (('u_hsv_color',(0, 96/100, 70/100)),('u_alpha', 1.0), ('u_rotation_offset',0.0)),
                'visible':  True,
            },
            {
                'name':     'wires B out',
                'field':    'wires_direction_b_out',    
                'dtype':    np.uint8,             
                'shader':   wire_shader,  
                'shader_uniforms': (('u_hsv_color',(0, 96/100, 70/100)),('u_alpha', 1.0),),
                'visible':  True,
            },

            {
                'name':     'Wire A spikes',
                'field':    'wires_spike_a',    
                'dtype':    np.uint8,             
                'shader':   bool_hsv_shader,  
                'shader_uniforms': (('u_hsv_color',(248/360, 80/100, 83/100)),('u_alpha', 0.6),('u_border_radius', 0.6)),
                'visible':  True,
            },
            {
                'name':     'wires A in',
                'field':    'wires_direction_a_in',    
                'dtype':    np.uint8,             
                'shader':   wire_shader,  
                'shader_uniforms': (('u_hsv_color',(248/360, 96/100, 70/100)),('u_alpha', 1.0), ('u_rotation_offset',0.0)),
                'visible':  True,
            },
            {
                'name':     'wires A out',
                'field':    'wires_direction_a_out',    
                'dtype':    np.uint8,             
                'shader':   wire_shader,  
                'shader_uniforms': (('u_hsv_color',(248/360, 96/100, 70/100)),('u_alpha', 1.0),),
                'visible':  True,
            },


            {
                'name':     'trails',
                'field':    'trails_channel',    
                'dtype':    np.uint8,             
                'shader':   u8_hsv_mapped_shader,  
                'shader_uniforms': (('u_alpha', 1.0),),
                'visible':  True,
            },
        ],
        ui_model=uim,
        fps=60,
        window_size = (1920, 1080),
    )

    viz.start()