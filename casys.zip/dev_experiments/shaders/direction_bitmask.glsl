#define PI 3.14159265358979323846

#define N 1u << 0
#define NE 1u << 1
#define E 1u << 2
#define SE 1u << 3
#define S 1u << 4
#define SW 1u << 5
#define W 1u << 6
#define NW 1u << 7

uniform float u_alpha = 1.0;
uniform float u_pointer_radius = 0.3;
uniform float u_pointer_offset = 0.7;
uniform float u_rotation_offset = 0.0;

float sdEquilateralTriangle( in vec2 p, in float r ) {
    const float k = sqrt(3.0);
    p.x = abs(p.x) - r;
    p.y = p.y + r/k;
    if( p.x+k*p.y>0.0 ) p = vec2(p.x-k*p.y,-k*p.x-p.y)/2.0;
    p.x -= clamp( p.x, -2.0*r, 0.0 );
    return -length(p)*sign(p.y);
}

vec2 rotateVec2(vec2 p, float th) {
    mat2x2 rotMat = mat2x2(
        cos(th), -sin(th),
        sin(th),  cos(th)
    );
    return p*rotMat;
}

float sdOrientedBox( in vec2 p, in vec2 a, in vec2 b, float th )
{
    float l = length(b-a);
    vec2  d = (b-a)/l;
    vec2  q = (p-(a+b)*0.5);
          q = mat2(d.x,-d.y,d.y,d.x)*q;
          q = abs(q)-vec2(l,th)*0.5;
    return length(max(q,0.0)) + min(max(q.x,q.y),0.0);    
}

float sdTriangleIsosceles( in vec2 p, in vec2 q )
{
    p.x = abs(p.x);
    vec2 a = p - q*clamp( dot(p,q)/dot(q,q), 0.0, 1.0 );
    vec2 b = p - q*vec2( clamp( p.x/q.x, 0.0, 1.0 ), 1.0 );
    float s = -sign( q.y );
    vec2 d = min( vec2( dot(a,a), s*(p.x*q.y-p.y*q.x) ),
                  vec2( dot(b,b), s*(p.y-q.y)  ));
    return -sqrt(d.x)*sign(d.y);
}

float getArrow(vec2 p, uint dir) {
    if (dir == 0u) return 2.0;
    float shift = mod((log2(float(dir)) + u_rotation_offset),8);
    float th = -(shift * (2.0*PI/8.0));
    // float d_tri = sdTriangleIsosceles(rotateVec2(p-vec2(u_pointer_radius/2,u_pointer_radius*2.65),th), vec2(u_pointer_radius,u_pointer_radius*0.65));
    // float d_tri = sdTriangleIsosceles(rotateVec2(p+vec2(0,u_pointer_radius*0.65/2),-th) - vec2(0,u_pointer_offset), vec2(u_pointer_radius,u_pointer_radius));
    float d_tri = sdTriangleIsosceles(rotateVec2(p,-th) - vec2(0,u_pointer_offset*(1+0.3*mod(shift,2))), vec2(u_pointer_radius,u_pointer_radius));
    return d_tri;
    float d_box = sdOrientedBox(p, vec2(0,0), vec2(0,u_pointer_offset), u_pointer_radius/2);
    return min(d_tri,d_box);
}

void main() {
    vec2 c_uv = cell_uv();
    
    uint meta = sample_meta();

    if (meta == 0u) { discard; }

    vec2 p = (c_uv - 0.5) * 2;

    float d = min(
        min(
            min( getArrow(p, meta & N), getArrow(p, meta & NE)),
            min( getArrow(p, meta & E), getArrow(p, meta & SE))
        ),
        min(
            min( getArrow(p, meta & S), getArrow(p, meta & SW)),
            min( getArrow(p, meta & W), getArrow(p, meta & NW))
        )
    );


    if (d > 0) { discard; }
    
    float lightness = d > -0.15*u_pointer_radius ? 0.0 : 1.0;
    FragColor = vec4(lightness,lightness,lightness,u_alpha);
}