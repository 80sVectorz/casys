uniform float u_border_radius;
uniform float u_alpha = 1.0;

void main() {
    vec2 c_uv = cell_uv();
    
    vec2 border = abs(c_uv - 0.5) * 2;
    if (max(border.x,border.y) > 1 - u_border_radius) {
        discard;
    }

    uint meta = sample_meta();
    if (meta == 0u) {
        discard;
    }
    FragColor = vec4(1.0,1.0,1.0,u_alpha);
}