uniform vec3 u_color_a;
uniform vec3 u_color_b;
uniform float u_alpha = 1.0;
uniform float u_border_radius = 0.0;

vec3 lerp(vec3 a, vec3 b, float t) {
    return a*(1.0-t) + b*t;
}

void main() {
    vec2 c_uv = cell_uv();

    float meta = sample_meta_float();

    if (meta == 0u) {
        discard;
    }
    
    vec2 border = abs(c_uv - 0.5) * 2;
    if (max(border.x,border.y) > 1-u_border_radius) {
        discard;
    }
    
    FragColor = vec4(hsv2rgb(lerp(u_color_a,u_color_b,meta)), u_alpha);
}