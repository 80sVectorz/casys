uniform float u_alpha = 1.0;
uniform float u_border_radius = 0.0;

void main() {
    vec2 c_uv = cell_uv();

    uint meta = sample_meta();

    if (meta == 0u) {
        discard;
    }
    
    vec2 border = abs(c_uv - 0.5) * 2;
    if (max(border.x,border.y) > 1-u_border_radius) {
        discard;
    }
    
    FragColor = vec4(hsv2rgb(vec3(meta/255.0,1,0.8)), u_alpha);
}