from numba import njit
import numpy as np
from bit_op_utils import *

# Converts a direction bitmask to a (dx, dy) tuple.
@njit
def direction_to_vec(direction: np.uint8) -> tuple[np.int8, np.int8]:
    if direction == 0b0000_0001:
        return 0, 1
    elif direction == 0b0000_0010:
        return 1, 1
    elif direction == 0b0000_0100:
        return 1, 0
    elif direction == 0b0000_1000:
        return 1, -1
    elif direction == 0b0001_0000:
        return 0, -1
    elif direction == 0b0010_0000:
        return -1, -1
    elif direction == 0b0100_0000:
        return -1, 0
    elif direction == 0b1000_0000:
        return -1, 1
    return 0, 0

def direction_to_str(direction: np.uint8 | int):
    return ('N','NE','E','SE','S','SW','W','NW')[int(np.log2(np.uint8(direction)))]

@njit(inline='always')
def clamp01(x: float) -> float:
    return 0.0 if x < 0.0 else (1.0 if x > 1.0 else x)

@njit(inline='always')
def dir8_from_vec(dx: float, dy: float) -> np.uint8:
    """Map a 2D vector to the closest 8-way direction bit."""
    best_i = 0
    best_dot = -1e9
    for i in range(8):
        mask = np.uint8(1 << i)
        vx, vy = direction_to_vec(mask)
        # Normalize so diagonals are comparable to cardinals.
        n = 1.0 if (vx == 0 or vy == 0) else np.sqrt(2.0)
        dot = (dx * vx + dy * vy) / n
        if dot > best_dot:
            best_dot = dot
            best_i = i
    return np.uint8(1 << best_i)

# Rotates a direction bitmask by a given offset.
@njit(inline='always')
def rotate_direction(direction: np.uint8 | int, offset: np.int8 | int) -> np.uint8:
    return rol8(np.uint8(direction), offset%8) # type: ignore