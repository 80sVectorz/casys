import numpy as np
from numba import njit

# Converts a direction bitmask to a (dx, dy) tuple.
@njit
def direction_to_vec(direction: np.uint8) -> tuple[np.int8, np.int8]:
    if direction == 0b0000_0001:
        return 0, 1
    elif direction == 0b0000_0010:
        return 1, 1
    elif direction == 0b0000_0100:
        return 1, 0
    elif direction == 0b0000_1000:
        return 1, -1
    elif direction == 0b0001_0000:
        return 0, -1
    elif direction == 0b0010_0000:
        return -1, -1
    elif direction == 0b0100_0000:
        return -1, 0
    elif direction == 0b1000_0000:
        return -1, 1
    return 0, 0

def direction_to_str(direction: np.uint8 | int):
    return ('N','NE','E','SE','S','SW','W','NW')[int(np.log2(np.uint8(direction)))]

# Rotates a direction bitmask by a given offset.
@njit(inline='always')
def rotate_direction(direction: np.uint8 | int, offset: np.int8 | int) -> np.uint8:
    return rol8(np.uint8(direction), offset%8) # type: ignore