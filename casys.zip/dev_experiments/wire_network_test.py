from typing import Any
from numba.parfors.parfor import swap_functions_map
import numpy as np
import random
import numba
from numba import njit
from casys import *
from casys.dsl.kernel_utils import k_eval, k_get_const, k_get_pos, k_get_dims, k_mark_pos, k_patch_op, k_get_timestamp, step_func_split, k_neighbor_mask, step_func_swap

from rng_util import *
from direction_utils import *
from shaders import *

from casys.config import CASYS_CONFIG
from casys.logging import setup_logging

CASYS_CONFIG.debug_ast_timeline = True
# CASYS_CONFIG.debug_jit_nopython = False
# CASYS_CONFIG.debug_disable_jit = 'full'
CASYS_CONFIG.debug_dynsrc_mode = 'mirror'

setup_logging(verbose=False)

@cac_type
class Leader:
    channel: cact_field[np.uint8, int]

    intent_next_direction: cact_field[np.uint8, int]
    resolved_next_owner: cact_field[np.uint8, int]

    steps_left: cact_field[np.uint16, int]

@cac_type
class Wire:
    direction_a_in: cact_field[np.uint8, int] # Wire's main input direction
    direction_a_out: cact_field[np.uint8, int] # Wire's main output direction
    direction_b_in: cact_field[np.uint8, int]
    direction_b_out: cact_field[np.uint8, int]
    spike_a: cact_field[np.uint8, int]
    spike_b: cact_field[np.uint8, int]

@cac_type
class Chemicals:
    """
    Holds different types of signaling chemicals and morphogens.
    Each field represents a chemical and the concentration of that chemical in each cell.
    At 0 the chemical isn't present
    """
    excitant: cact_field[np.float32, float]
    neuro_presence: cact_field[np.float32, float]

@cac_type
class Neuron:
    active: cact_field[np.uint8, int]
    charge: cact_field[np.float32, float]
    spike: cact_field[np.uint8, int]
    refractory_timer: cact_field[np.uint8, int]
    first_connection_x: cact_field[np.int8, int]
    first_connection_y: cact_field[np.int8, int]

@cac_type
class Connection:
    neuron_dx: cact_field[np.int8, int]
    neuron_dy: cact_field[np.int8, int]
    input_direction: cact_field[np.uint8, int]

    spike_out: cact_field[np.uint8, int]
    active: cact_field[np.uint8, int]
    weight: cact_field[np.float32, int]

    spike_in: cact_field[np.uint8, int]

@cac_type
class Trail:
    channel: cact_field[np.uint8, int]

    # directions are relative to each cell.
    # t=1                  t=2
    # · · ·                · ·  · ·
    # · #→· <-- next dir   · #→←#→·
    #   ↓  <-- prev dir      ↓
    #   ↑                    ↑
    # · # ·                · #  · ·
    next_direction: cact_field[np.uint8, int] # Direction of the next element in the trail
    prev_direction: cact_field[np.uint8, int] # Direction of the previous element in the trail

DIM = 2**8
DIMS = (DIM, DIM)
WIRE_CHANNEL_WIDTH = 8

class Constants(DefaultCaSimConstants):
    dims = DIMS

    c_decay_neuro_presence = 1 - 0.001
    c_decay_excitant = 1 - 0.0001

    leader_chem_eps = 1e-6
    leader_chem_g_k = 0.2      # larger -> need stronger gradients to favor drift
    leader_chem_c_k = 0.05     # larger -> concentration contributes less to drift
    leader_chem_alpha = 0.75   # weight of gradient vs concentration in p_dr

    neuron_refractory_period = 100
    charge_decay = 1 - 0.001
    initial_weight = 0.1


# The main update kernel for leader movement and trail marking.
@ca_kernel
def leaders_move_step(
    leaders: Leader,
    trails: Trail,
    connections: Connection,
    chemicals: Chemicals,
    neurons: Neuron,
) -> None:
    timestamp = k_get_timestamp()
    x, y = k_get_pos()

    channel = leaders.channel
    next_owner_dir = leaders.resolved_next_owner
    if channel == 0 and next_owner_dir == 0: return
    
    rng_seed = rng_hash(x,y,timestamp)
    channel = leaders.channel

    neuro_presence = chemicals.neuro_presence[x, y]

    if channel != 0:
        steps_left = leaders.steps_left
        if steps_left > 0:
            steps_left = leaders.steps_left - 1

            # Get next direction
            next_direction = leaders.intent_next_direction
            dx, dy = direction_to_vec(next_direction) # type: ignore

            nx, ny = x + dx, y + dy ; k_mark_pos()

            if leaders.resolved_next_owner[nx,ny] != rotate_direction(next_direction, 4): # type: ignore
                # Agent is stuck and cannot move. This means that this cell stays occupied
                next_direction = 0b1 << np.uint8(rng_int(rng_seed, 0,7))
                leaders.intent_next_direction[x, y] = next_direction
                leaders.steps_left[x,y] = steps_left

                trails.channel = channel
                trails.next_direction[x,y] = next_direction
                return

            trails.channel = channel
            trails.next_direction[x,y] = next_direction

            neurons_check = bool(neurons.active[nx,ny])
            connections_check = bool(connections.active[nx,ny])

            if neurons_check or connections_check:
                connections.active[x,y] = 1
                connections.weight[x,y] = k_get_const(np.float32, 'initial_weight')
                if neurons_check:
                    connections.neuron_dx[x,y] = dx
                    connections.neuron_dy[x,y] = dy
                else:
                    connections.neuron_dx[x,y] = connections.neuron_dx[nx,ny] - dx
                    connections.neuron_dy[x,y] = connections.neuron_dy[nx,ny] - dy


        elif next_owner_dir == 0:
            # Agent died and no other cell wants to move here

            leaders.channel[x,y] = 0
            leaders.intent_next_direction[x,y] = 0

            rng_seed = rng_chain(rng_seed)
            if rng_int(rng_seed, 0,25) > 100*neuro_presence:
                neurons.active[x,y] = 1
            return

    if next_owner_dir:

        no_dx,no_dy = direction_to_vec(next_owner_dir) # type: ignore
        no_x,no_y = x+no_dx, y+no_dy ; k_mark_pos()

        new_steps_left = leaders.steps_left[no_x,no_y]

        if new_steps_left > 0:
            new_steps_left -= 1

            # --- Chemotaxis, no extra state ---
            # Local stats
            c_avg = k_patch_op('mean', chemicals.neuro_presence, x, y, 3, 3, [
                [1, 1, 1],
                [1, 1, 1],
                [1, 1, 1],
            ])
            eps = k_get_const(np.float32, 'leader_chem_eps')

            # Sobel gradient
            gx = k_patch_op('sum', chemicals.neuro_presence, x, y, 3, 3, [
                [-1, 0, 1],
                [-2, 0, 2],
                [-1, 0, 1],
            ])
            gy = k_patch_op('sum', chemicals.neuro_presence, x, y, 3, 3, [
                [-1, -2, -1],
                [ 0,  0,  0],
                [ 1,  2,  1],
            ])
            g = np.sqrt(gx * gx + gy * gy)

            # Unit "forward" based on the move we just took into (x,y).
            # next_owner_dir points from this cell toward the previous cell,
            # so rotate by 4 to get the actual forward direction.
            fwd_dir = rotate_direction(next_owner_dir, 4)
            vx, vy = direction_to_vec(fwd_dir)  # type: ignore

            # Alignment of current motion with +grad. In [-1, 1].
            # < 0 means we are moving downhill; > 0 means moving uphill.
            align = (gx * vx + gy * vy) / (g + eps)

            # Decide downhill vs uphill purely by alignment sign, softened a bit.
            # s in {-1, +1} prefers -grad when align < 0, +grad when align >= 0.
            s = 1.0 if align >= 0.0 else -1.0

            # Drift vector aims along chosen side of the gradient.
            drift_dx = s * gx
            drift_dy = s * gy

            # Strength of drift vs random: stronger when gradient is strong and/or
            # concentration is nontrivial. No absolute units required.
            wg = g / (g + k_get_const(np.float32, 'leader_chem_g_k'))
            wc = c_avg / (c_avg + k_get_const(np.float32, 'leader_chem_c_k'))
            p_drift = clamp01(k_get_const(np.float32, 'leader_chem_alpha') * wg
                            + (1.0 - k_get_const(np.float32, 'leader_chem_alpha')) * wc)

            # Draw the intent
            rng_seed = rng_chain(rng_seed)
            pick = rng_int(rng_seed, 0, 1023)
            if pick < int(p_drift * 1023.0):
                # Snap drift to 8-dir
                new_direction = dir8_from_vec(drift_dx, drift_dy)
            else:
                # Random, with a small bias to keep some momentum
                rng_seed = rng_chain(rng_seed)
                offset = rng_int(rng_seed, -1, 1)  # type: ignore
                new_direction = rotate_direction(fwd_dir, offset)

            leaders.intent_next_direction[x, y] = new_direction
            trails.next_direction[x, y] = new_direction
            # rng_seed = rng_chain(rng_seed)
            # random_offset = rng_int(rng_seed, -1, 1) # type: ignore
            # new_direction = rotate_direction(next_owner_dir, 4+random_offset) # type: ignore
            # leaders.intent_next_direction[x,y] = new_direction
            # trails.next_direction[x,y] = new_direction
        # else:
        #     leaders.intent_next_direction[x,y] = 0

        new_channel = leaders.channel[no_x,no_y]
        leaders.channel[x,y] = new_channel
        leaders.steps_left[x,y] = new_steps_left

        trails.channel[x,y] = new_channel
        trails.prev_direction[x,y] = next_owner_dir
    else:
        leaders.channel[x,y] = 0
        leaders.intent_next_direction[x,y] = 0
        leaders.steps_left[x,y] = 0


@ca_kernel
def leader_claims_update_step(
    leaders: Leader,
    trails: Trail,
    wires: Wire,
):
    x, y = k_get_pos()
    timestamp = k_get_timestamp()

    wire_da_in = wires.direction_a_in[x,y]
    wire_db_in = wires.direction_b_in[x,y]

    winner = 0
    if (
        leaders.channel == 0
        and trails.channel==0
        and ( 
            (wire_da_in == 0) or
            (wire_db_in == 0)
        )
    ):
        rng_seed = rng_hash(x,y,timestamp)

        neighbors_interested = k_neighbor_mask(
            x=x,y=y,d=(d:=0),
            expr=(
                    (leaders.channel[x,y]>0 and leaders.steps_left[x,y]>0)
                    and (
                        (wire_da_in == 0 and wires.direction_b_in[x,y] == 0) or
                        (wire_db_in == 0 and wires.direction_a_in[x,y] == 0)
                    )
                    and (leaders.intent_next_direction[x,y] == rotate_direction(d,4))
                )
        )

        if neighbors_interested != 0:
            check_dir = np.uint8(rng_int(rng_seed, 0,7))
            while winner == 0:
                check_dir += 1
                if check_dir > 7:
                    check_dir = 0
                winner = neighbors_interested & (0b1 << check_dir)

    leaders.resolved_next_owner[x,y] = winner

@ca_kernel
def trails_update_step(
    trails: Trail,
    leaders: Leader,
    connections: Connection,
    wires: Wire,
):
    x,y = k_get_pos()

    channel = trails.channel[x,y]
    next_direction = trails.next_direction[x,y]
    if channel | next_direction == 0: return

    next_direction_flipped = rotate_direction(next_direction, 4)
    n_dx,n_dy = direction_to_vec(next_direction) # type: ignore
    nx,ny = x+n_dx, y+n_dy ; k_mark_pos()

    prev_direction = trails.prev_direction[x,y]

    if (
        not (trails.channel[nx,ny] == channel and trails.prev_direction[nx,ny] == next_direction_flipped)
        and leaders.channel[x,y] != channel 
        and leaders.channel[nx,ny] != channel 
    ) :
        if connections.active[nx,ny] != 0 or (wires.direction_a_in[nx,ny] | wires.direction_b_in[nx,ny]) & next_direction_flipped != 0:
            if wires.direction_a_in[x,y] == 0:
                wires.direction_a_in[x,y] = prev_direction
                wires.direction_a_out[x,y] = next_direction
            elif wires.direction_b_in[x,y] == 0:
                wires.direction_b_in[x,y] = prev_direction
                wires.direction_b_out[x,y] = next_direction

        trails.channel[x,y] = 0
        trails.next_direction[x,y] = 0
        trails.prev_direction[x,y] = 0
        return

# @ca_kernel
# def connection_update_step(
#     connections: Connection
# ):
#     x,y = k_get_pos()
#     if connections.active[x,y] == 0: return

#     rng_seed = rng_hash(x,y,k_get_timestamp())

#     if rng_int(rng_seed,0,10) == 0:
#         connections.spike_out[x,y] = 1.0

@ca_kernel
def connection_inject_from_wires_step(
    wires: Wire,
    connections: Connection,
) -> None:
    """Seed connection.spike_in when an adjacent wire outputs into this cell."""
    x, y = k_get_pos()
    if connections.active[x,y] == 0:
        connections.spike_in[x,y] = 0
        return

    hit = 0

    # Check 8 neighbors for a wire whose out_dir points at me
    for i in range(8):
        d = np.uint8(0b1 << i)
        dx, dy = direction_to_vec(d)  # type: ignore
        nx, ny = x + dx, y + dy ; k_mark_pos()

        want = rotate_direction(d, 4)  # neighbor's out must face me

        if wires.direction_a_out[nx,ny] == want and wires.spike_a[nx,ny] != 0:
            hit = 1
            break
        if wires.direction_b_out[nx,ny] == want and wires.spike_b[nx,ny] != 0:
            hit = 1
            break

    connections.spike_in[x,y] = np.uint8(hit)

@ca_kernel
def connection_convey_step(
    connections: Connection,
    neurons: Neuron
) -> None:
    """
    Move spike_in one cell closer to the neuron using the per-cell vector field.
    One hop per tick, no extra delay logic.
    """
    x, y = k_get_pos()
    if connections.active[x,y] == 0: return

    nx,ny = (
        x+connections.neuron_dx,
        y+connections.neuron_dy,
    ) ; k_mark_pos()
    
    connections.spike_out[x,y] = neurons.spike[nx,ny]

    # # Clear by default
    # carry = np.uint8(0)

    # # Look for spike from the upstream neighbor (one step farther from soma).
    # # Upstream is the opposite of our local -sign(neuron_dx/dy).
    # dx_to_neuron = int(connections.neuron_dx[x,y])
    # dy_to_neuron = int(connections.neuron_dy[x,y])
    # if dx_to_neuron == 0 and dy_to_neuron == 0:
    #     # This should only happen on the soma cell itself if you ever mark it active.
    #     connections.spike_in[x,y] = 0
    #     return

    # # Step sign away from neuron to find upstream
    # sx, sy = (
    #     x + (1 if dx_to_neuron > 0 else (-1 if dx_to_neuron < 0 else 0)),
    #     y + (1 if dy_to_neuron > 0 else (-1 if dy_to_neuron < 0 else 0)),
    # ) ; k_mark_pos()

    # # If that upstream cell belongs to the same connection corridor, take its spike.
    # if connections.active[sx,sy] != 0:
    #     carry = connections.spike_in[sx,sy]

    # # Also OR with local injection (wire adjacency) that happened this tick.
    # carry = np.uint8(carry | connections.spike_in[x,y])

    # connections.spike_in[x,y] = carry

@ca_kernel
def neuron_update_step(
    neurons: Neuron,
    connections: Connection,
    chemicals: Chemicals,
    leaders: Leader,
):
    x,y = k_get_pos()
    timestamp = k_get_timestamp()

    if neurons.active[x,y] == 0: return

    refractory_timer = neurons.refractory_timer[x,y]
    if refractory_timer:
        neurons.refractory_timer[x,y] = refractory_timer - 1

    rng_seed = rng_hash(x,y,timestamp)

    chemicals.neuro_presence[x,y] = 1.0

    if rng_int(rng_seed,0,100) == 0:
        rng_seed = rng_chain(rng_seed)
        leaders.channel[x,y] = rng_int(rng_seed,0,255)
        rng_seed = rng_chain(rng_seed)
        leaders.intent_next_direction[x,y] = 0b1 << rng_int(rng_seed,0,7)
        rng_seed = rng_chain(rng_seed)
        leaders.steps_left[x,y] = 15 + np.uint16(rng_int(rng_seed,0,50))

@ca_kernel
def neuron_receive_step(
    neurons: Neuron,
    connections: Connection,
    chemicals: Chemicals,
) -> None:
    """
    Sum weighted spikes from connection cells in a small halo around the soma.
    This allows fan-in >> 8 in a single tick.
    """
    x, y = k_get_pos()
    if neurons.active[x,y] == 0:
        return

    acc = neurons.charge[x,y] * k_get_const(np.float32, 'charge_decay')

    excitant_levels = chemicals.excitant[x,y]
    if excitant_levels:
        rng_seed = rng_hash(x,y, k_get_timestamp())
        if rng_int(rng_seed, 0, 100) < excitant_levels*100:
            acc += 0.05

    # Halo radius: 2 is cheap and already gives 24 cells; increase if you want.
    R = 2
    for oy in range(-R, R+1):
        for ox in range(-R, R+1):
            if ox == 0 and oy == 0:
                continue
            nx, ny = x + ox, y + oy ; k_mark_pos()
            if connections.active[nx,ny] == 0:
                continue

            if (
                connections.spike_in[nx,ny] != 0
                and nx+connections.neuron_dx[nx,ny] == x
                and ny+connections.neuron_dy[nx,ny] == y
            ):
                w = float(connections.weight[nx,ny])
                acc += w  # or w * spike amplitude if you extend beyond binary

    neurons.charge[x,y] = acc

    if acc > 1 and not neurons.refractory_timer[x,y]:
        neurons.charge[x,y] = 0
        neurons.spike[x,y] = 1
        neurons.refractory_timer[x,y] = k_get_const(np.uint8, 'neuron_refractory_period')

@ca_kernel
def update_wires_and_spikes(
    wires: Wire,
    connections: Connection,
    neurons: Neuron,
    trails: Trail,
):
    x,y = k_get_pos()

    connections.spike_out[x,y] = 0
    neurons.spike[x,y] = 0
    wires.spike_a[x,y] = 0
    wires.spike_b[x,y] = 0


    d_a_in = wires.direction_a_in[x,y]
    d_b_in = wires.direction_b_in[x,y]
    d_a_out = wires.direction_a_out[x,y]
    d_b_out = wires.direction_b_out[x,y]

    if (d_a_in | d_a_out | d_b_in | d_b_out) == 0: return

    dc_x,dc_y = x,y ; k_mark_pos()

    if d_a_in != 0:
        dc_dx,dc_dy = direction_to_vec(d_a_in) # type: ignore
        dc_x,dc_y = x+dc_dx,y+dc_dy
        connection_spike = (
            (connections.spike_out[dc_x,dc_y] | neurons.spike[dc_x,dc_y])
            & (connections.active[dc_x,dc_y] | neurons.active[dc_x,dc_y])
        )
        if connection_spike:
            wires.spike_a[x,y] = 1
        elif wires.direction_a_out[dc_x,dc_y] | wires.direction_b_out[dc_x,dc_y] | connections.active[dc_x,dc_y] != 0:
            neighbor_spike_a = wires.spike_a[dc_x,dc_y]
            neighbor_spike_b = wires.spike_b[dc_x,dc_y]
            spike_check = ((wires.direction_a_out[dc_x,dc_y]*neighbor_spike_a) | (wires.direction_b_out[dc_x,dc_y]*neighbor_spike_b)) & rotate_direction(d_a_in,4) 
            
            wires.spike_a[x,y] = spike_check != 0
        elif connections.active[dc_x,dc_y] | neurons.active[dc_x,dc_y] == 0 and trails.next_direction[dc_x,dc_y] != rotate_direction(d_a_in,4):
            wires.direction_a_in[x,y] = 0
            wires.direction_a_out[x,y] = 0

    if d_b_in != 0:
        dc_dx,dc_dy = direction_to_vec(d_b_in) # type: ignore
        dc_x,dc_y = x+dc_dx,y+dc_dy
        connection_spike = (
            (connections.spike_out[dc_x,dc_y] | neurons.spike[dc_x,dc_y])
            & (connections.active[dc_x,dc_y] | neurons.active[dc_x,dc_y])
        )
        if connection_spike:
            wires.spike_b[x,y] = 1
        elif wires.direction_a_out[dc_x,dc_y] | wires.direction_b_out[dc_x,dc_y] | connections.active[dc_x,dc_y] != 0:
            neighbor_spike_a = wires.spike_a[dc_x,dc_y]
            neighbor_spike_b = wires.spike_b[dc_x,dc_y]
            spike_check = ((wires.direction_a_out[dc_x,dc_y]*neighbor_spike_a) | (wires.direction_b_out[dc_x,dc_y]*neighbor_spike_b)) & rotate_direction(d_b_in,4)
            wires.spike_b[x,y] = spike_check != 0
        elif connections.active[dc_x,dc_y] | neurons.active[dc_x,dc_y]  == 0 and trails.next_direction[dc_x,dc_y] != rotate_direction(d_b_in,4):
            wires.direction_b_in[x,y] = 0
            wires.direction_b_out[x,y] = 0

DIFFUSION_MATRIX = [
    [.05,.1,.05],
    [.1 ,.4,.1 ],
    [.05,.1,.05],
]

@ca_kernel
def chemicals_update_step(
    chemicals: Chemicals,
) -> None:
    x, y = k_get_pos()

    chemicals.neuro_presence = (
        k_patch_op('sum', chemicals.neuro_presence,x,y,3,3,k_eval(DIFFUSION_MATRIX))
        * k_eval(Constants.c_decay_neuro_presence)
    ) 

    chemicals.excitant = (
        k_patch_op('sum', chemicals.excitant,x,y,3,3,k_eval(DIFFUSION_MATRIX))
        * k_eval(Constants.c_decay_excitant)
    )

@ca_sys_step_func
def step_fn(
    leaders: Leader,
    trails: Trail,

    chemicals: Chemicals,

    neurons: Neuron,
    connections: Connection,
    wires: Wire,

) -> None:
    connection_inject_from_wires_step(wires, connections)
    update_wires_and_spikes(wires, connections, neurons, trails)

    step_func_swap([wires, connections])

    neuron_receive_step(neurons, connections, chemicals)

    step_func_swap([neurons])

    connection_convey_step(connections, neurons)

    neuron_update_step(neurons, connections, chemicals, leaders)
    leaders_move_step(leaders, trails, connections, chemicals, neurons)
    trails_update_step(trails, leaders, connections, wires)

    step_func_swap([leaders, chemicals])

    chemicals_update_step(chemicals)
    leader_claims_update_step(leaders, trails, wires)    

    # spikes_update_step(wires,connections)
    # connection_update_step(connections)
    # neuron_update_step(neurons, connections, chemicals, leaders)

    # leaders_move_step(leaders,trails, connections,chemicals, neurons)
    # trails_update_step(trails,leaders,connections,wires)

    # step_func_split()
    # step_func_swap([leaders, chemicals])

    # chemicals_update_step(chemicals)
    # leader_claims_update_step(leaders, trails, wires)


# leader_ca_system = CASystem(
#     step_fn=step_fn,
# )

sim = CaSim.from_step_func(step_fn, Constants)

if __name__ == '__main__':
    import pathlib
    from casys.viz import Visualizer
    from casys.viz.gui.ui_model import UIModel

    random.seed(0)

    def random_leader(steps_left = 15) -> tuple[tuple[str,Any],...]:
        return (
            ('leaders_intent_next_direction', np.uint8(0b1 << random.randint(0, b=7))),
            ('leaders_channel', np.uint8(random.randint(1,255))),
            ('leaders_steps_left', steps_left)
        )

    n_random_cells = 5
    cell_edits = tuple(
        (
            random.randrange(0, DIMS[0]), random.randrange(0, DIMS[1]), random_leader(steps_left=random.randint(15,400))

        ) for _ in range(n_random_cells)
    )
    channels = set([edit[2] for _,_,edit in cell_edits])
    print(f'#unique leaders: {len(channels)}')

    sim.edit_cells(  cell_edits)

    sim_mgr = SimManager(sim,0.1, history_buffer_len=20)

    uim = UIModel()

    def info_fld_simulation_time() -> str:
        return str(sim.timestamp)

    def info_fld_simulation_performance() -> str:
        fps = sim_mgr.fps_ema or sim_mgr.fps_avg or 0
        ms = sim_mgr.last_step_ms or 0
        return str(f'FPS ~ {fps:.1f} (step {ms:.2f} ms)')
    
    uim.add_info_field('Sim Timestep: ',info_fld_simulation_time)
    uim.add_info_field('Sim Performance: ',info_fld_simulation_performance)
    
    def i_processor_direction_value(val) -> str:
        if val == 0:
            return 'NO DIR'
        print(f'{np.uint8(val):#010b} ({direction_to_str(val)}) | 180 {(flipped:=np.uint8(rotate_direction(val, 4))):#010b} (({direction_to_str(flipped)}))')
        return ('N','NE','E','SE','S','SW','W','NW')[int(np.log2(val))]

    def i_processor_direction_bitmask_value(val) -> str:
        if val == 0:
            return 'NO DIR'

        res = []
        print(f'[{np.uint8(val):#010b}')

        for i in range(8):
            if val & (0b1 << i):
                res.append(('N','NE','E','SE','S','SW','W','NW')[i])
                print(f'\t{(v:=np.uint8(0b1 << i)):#010b} ({direction_to_str(v)}) | 180 {(flipped:=np.uint8(rotate_direction(v, 4))):#010b} (({direction_to_str(flipped)}))')
        print(f']')

        return ', '.join(res)

    def i_processor_binary(val) -> str:
        return f'{val:#010b}'
    
    def tool_spawn_leader(pos_press: tuple[int,int], pos_release: tuple[int,int]):
        sim.edit_cells(( (*pos_release,random_leader()),))

    def tool_spike(pos_press: tuple[int,int], pos_release: tuple[int,int]):
        sim.edit_cells(( (*pos_release,(('wires_spike_a',1),('wires_spike_b',1))),))

    def tool_excitant(pos_press: tuple[int,int], pos_release: tuple[int,int]):
        sim.edit_cells(( (*pos_release,(('chemicals_excitant',1.0),)),))
    
    # viz.add_info_field(info_fld_n_leaders, '#active leaders')
    
    uim.register_inspect_processors(
        [
            'leaders_intent_next_direction',
            'leaders_intent_next_direction',
            'trails_prev_direction',
            'trails_next_direction',
            'wires_direction_a_in',
            'wires_direction_a_out',
            'wires_direction_b_in',
            'wires_direction_b_out',
        ],
    i_processor_direction_value
    )
    uim.register_inspect_processors(['leaders_cell_claimed_by'],i_processor_direction_bitmask_value)

    uim.register_tool('Spawn leader', tool_spawn_leader)
    uim.register_tool('Spike', tool_spike)
    uim.register_tool('Add Excitant', tool_excitant)

    viz = Visualizer(
        sim_manager=sim_mgr,
        layers_cfg = [
            {
                'name':     'Neurons',
                'field':    'neurons_active',    
                'dtype':    np.uint8,             
                'shader':   bool_hsv_shader,  
                'shader_uniforms': (('u_hsv_color',(0,0.0,0.9)),('u_border_radius', 0.0),),
                'visible':  True,
            },
            {
                'name':     'Connections',
                'field':    'connections_active',    
                'dtype':    np.uint8,             
                'shader':   bool_hsv_shader,  
                'shader_uniforms': (('u_hsv_color',(0,0.0,0.7)),('u_border_radius', 0.5),),
                'visible':  True,
            },
            {
                'name':     'Leader channels',
                'field':    'leaders_channel',    
                'dtype':    np.uint8,             
                'shader':   u8_hsv_mapped_shader,  
                'shader_uniforms': (('u_border_radius', 0.6),('u_alpha',1.0),),
                'visible':  True,
            },
            {
                'name':     'leaders',
                'field':    'leaders_channel',    
                'dtype':    np.uint8,             
                'shader':   bool_white_shader,  
                'shader_uniforms': (('u_border_radius', 0.4),),
                'visible':  True,
            },
            {
                'name':     'Trail directions',
                'field':    'trails_next_direction',    
                'dtype':    np.uint8,             
                'shader':   direction_bitmask_shader,
                'shader_uniforms': (
                    ('u_pointer_radius', 0.4),
                    ('u_pointer_offset', -0.2),
                    ('u_rotation_offset', 4.0),
                    ('u_alpha', 1.0),
                    ),
                'visible':  True,
            },

            {
                'name':     'Wire B spikes',
                'field':    'wires_spike_b',    
                'dtype':    np.uint8,             
                'shader':   bool_hsv_shader,  
                'shader_uniforms': (('u_hsv_color',(0, 80/100, 83/100)),('u_alpha', 0.6),('u_border_radius', 0.6)),
                'visible':  True,
            },
            {
                'name':     'wires B in',
                'field':    'wires_direction_b_in',    
                'dtype':    np.uint8,             
                'shader':   wire_shader,  
                'shader_uniforms': (('u_hsv_color',(0, 96/100, 70/100)),('u_alpha', 1.0), ('u_rotation_offset',0.0)),
                'visible':  True,
            },
            {
                'name':     'wires B out',
                'field':    'wires_direction_b_out',    
                'dtype':    np.uint8,             
                'shader':   wire_shader,  
                'shader_uniforms': (('u_hsv_color',(0, 96/100, 70/100)),('u_alpha', 1.0),),
                'visible':  True,
            },

            {
                'name':     'Wire A spikes',
                'field':    'wires_spike_a',    
                'dtype':    np.uint8,             
                'shader':   bool_hsv_shader,  
                'shader_uniforms': (('u_hsv_color',(248/360, 80/100, 83/100)),('u_alpha', 0.6),('u_border_radius', 0.6)),
                'visible':  True,
            },
            {
                'name':     'wires A in',
                'field':    'wires_direction_a_in',    
                'dtype':    np.uint8,             
                'shader':   wire_shader,  
                'shader_uniforms': (('u_hsv_color',(248/360, 96/100, 70/100)),('u_alpha', 1.0), ('u_rotation_offset',0.0)),
                'visible':  True,
            },
            {
                'name':     'wires A out',
                'field':    'wires_direction_a_out',    
                'dtype':    np.uint8,             
                'shader':   wire_shader,  
                'shader_uniforms': (('u_hsv_color',(248/360, 96/100, 70/100)),('u_alpha', 1.0),),
                'visible':  True,
            },


            {
                'name':     'trails',
                'field':    'trails_channel',    
                'dtype':    np.uint8,             
                'shader':   u8_hsv_mapped_shader,  
                'shader_uniforms': (('u_alpha', 1.0),),
                'visible':  True,
            },

            {
                'name':     'CHEM: Excitant',
                'field':    'chemicals_excitant',    
                'dtype':    np.float32,             
                'shader':   float_hsv_lerp_shader,
                'shader_uniforms': (('u_alpha', 0.4),('u_color_a',(1-210.0/360.0, 1.0, 0.8)),('u_color_b',(1-210.0/360.0, 0.0, 1.0))),
                'visible':  True,
            },
            {
                'name':     'CHEM: neuro presence',
                'field':    'chemicals_neuro_presence',    
                'dtype':    np.float32,             
                'shader':   float_hsv_shader,
                'shader_uniforms': (('u_alpha', 0.6),),
                'visible':  True,
            },
        ],
        ui_model=uim,
        fps=60,
        window_size = (1920, 1080),
    )

    viz.start()