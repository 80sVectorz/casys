from numpy import uint8, uint32, uint64
from numba import njit

@njit(inline='always')
def rol8(x: uint8, n: int) -> uint8:
    # note: & 0xFF masks to 8 bits
    return uint8(((x << n) | (x >> (8 - n))) & uint8(0xFF))

@njit(inline='always')
def rol32(x: uint32, n: int) -> uint32:
    return uint32(((x << n) | (x >> (32 - n))) & uint32(0xFFFFFFFF))

@njit(inline='always')
def ror32(x: uint32, n: int) -> uint32:
    return uint32(((x >> n) | (x << (32 - n))) & uint32(0xFFFFFFFF))

@njit(inline='always')
def rol64(x: uint64, n: int) -> uint64:
    return uint64(((x << n) | (x >> (64 - n))) & uint64(0xFFFFFFFFFFFFFFFF))

@njit(inline='always')
def ror64(x: uint64, n: int) -> uint64:
    return uint64(((x >> n) | (x << (64 - n))) & uint64(0xFFFFFFFFFFFFFFFF))