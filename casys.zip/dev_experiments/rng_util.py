import numpy as np
from numba import njit

BASE_SEED: np.uint64 = np.uint64(0x1234_5678_9ABC_DEF0)

@njit
def splitmix64(state: np.uint64) -> np.uint64:
    """SplitMix64 integer mixer."""
    # this constant is (2**64) * (golden ratio)
    z = state + np.uint64(0x9E3779B97F4A7C15)
    z = (z ^ (z >> np.uint64(30))) * np.uint64(0xBF58476D1CE4E5B9)
    z = (z ^ (z >> np.uint64(27))) * np.uint64(0x94D049BB133111EB)
    return z ^ (z >> np.uint64(31))

@njit
def rng_hash(x: int, y: int, step: int) -> np.uint64:
    """Initial 64-bit hash from (x, y, step, BASE_SEED)."""
    s = BASE_SEED
    s = splitmix64(s ^ np.uint64(x))
    s = splitmix64(s ^ (np.uint64(y) << np.uint64(32)))
    s = splitmix64(s ^ np.uint64(step))
    return np.uint64(s)

@njit
def rng_chain(h: np.uint64) -> np.uint64:
    return splitmix64(h)

@njit
def rng_int(h: int | np.int_ | np.uint, lb: int, ub: int) -> np.int8:
    """
    Get int between (inclusive lower-bound) lb and (inclusive upper-bound) ub
    """
    span = ub - lb
    return lb + int(h % np.uint64(span + 1)) # type: ignore