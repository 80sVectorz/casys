from os import path
import numpy as np
import numba as nb
from casys import *
from casys.config import CASYS_CONFIG
from casys.core import dataclass
from casys.dsl.kernel_utils import k_get_pos, k_get_dims, k_get_const, k_patch_op
from casys.logging import setup_logging

CASYS_CONFIG.debug_ast_origin_tracking = True
CASYS_CONFIG.debug_ast_timeline = True

setup_logging(verbose=True)

@cac_type
class rec_gol:
    alive: cact_field[np.uint8, int] ; _alive: int = 0

DIM = 2**9
DIMS = (DIM,DIM)

@ca_kernel
def gol_update_fn(
    gol_cells: rec_gol,
) -> None:
    x, y = k_get_pos()

    last_state = gol_cells.alive
    pop_size = k_patch_op('sum', gol_cells.alive, x,y ,3,3, [
        [1,1,1],
        [1,0,1],
        [1,1,1],
    ])

    new_state = last_state

    if last_state == 1:
        if 2 <= pop_size <= 3:
            new_state = 1
        else:
            new_state = 0
    elif last_state == 0 and pop_size == 3:
        new_state = 1

    gol_cells.alive[x,y] = new_state

@ca_sys_step_func
def step_fn(
    gol_cells: rec_gol,
) -> None:
    gol_update_fn(gol_cells)

class constants(CaSimConstants):
    dims = DIMS

CaSim.from_step_func(step_fn,sim_constants=constants)

sim = CaSim(
    system=gol_ca_system,
    dims = DIMS,
)

def generate_edits(n_random: int):
    return tuple(
            (random.randrange(0, stop=DIMS[0]), random.randrange(0, DIMS[1]), (("alive", True),))
            for _ in range(n_random)
        )

if __name__ == "__main__":
    import random
    import pathlib
    from casys.viz import Visualizer
    from casys.viz.gui import ui_model

    n_random_cells = DIM**2 // 4
    cell_edits = tuple(
            (
                random.randrange(0,DIMS[0]), random.randrange(0,DIMS[1]),
                (
                    ('gol_cells_alive',True),
                )
            ) for _ in range(n_random_cells)
        )

    cell_edits = []
    for i in range(1000):
        ox = random.randrange(4, DIMS[0]-4)
        oy = random.randrange(4, DIMS[0]-4)
        for x,y in [ (1,0), (2,1), (0,2), (1,2), (2,2)]:
            cell_edits.append((ox+x,oy+y,
                (
                    ('gol_cells_alive',True),
                )))

    
    cell_edits = tuple(cell_edits)
        #     (
        #         4+x,4+y,
        #         (
        #             ('gol_cells_alive',True),
        #         )
        #     ) for x,y in [
        #         (1,0),
        #         (2,1),
        #         (0,2),
        #         (1,2),
        #         (2,2),
        #     ]
        # )
    
    
    sim.edit_cells(sim.ld_idx, cell_edits)
    
    sim_mgr = SimManager(sim,0.1)

    file_path = pathlib.Path(__file__)

    with open(file_path.parent/'shaders/bool_white_cells.glsl') as f:
        gol_shader = '\n'.join(f.readlines())

    viz = Visualizer(
        sim_mgr,
        layers_cfg = [
            {
                'name':     'GameOfLife',
                'field':    'gol_cells_alive',    
                'dtype':    np.uint8,             
                'shader':   gol_shader,  
                'visible':  True,
            },
        ],
        ui_model=ui_model.UIModel(),
        window_size = (800, 800),
        fps = 60,
    )

    viz.start()  # runs the render loop, calling sim.step() under the hood