def step_fn(leaders_channel, leaders_intent_next_direction, leaders_resolved_next_owner, leaders_steps_left, trails_channel, trails_next_direction, trails_prev_direction, chemicals_excitant, chemicals_neuro_presence, neurons_active, neurons_charge, neurons_spike, neurons_refractory_timer, neurons_first_connection_x, neurons_first_connection_y, connections_neuron_dx, connections_neuron_dy, connections_input_direction, connections_spike_out, connections_active, connections_weight, connections_spike_in, wires_direction_a_in, wires_direction_a_out, wires_direction_b_in, wires_direction_b_out, wires_spike_a, wires_spike_b, kval_wr_idx, kval_wr_idx_neurons, kval_wr_idx_leaders, kval_wr_idx_chemicals, kval_wr_idx_wires, kval_wr_idx_connections, kval_timestamp, /):
    for kval_p_ax0 in numba.prange(256):
        for kval_p_ax1 in numba.prange(256):
            wires_direction_b_in[kval_wr_idx_wires, kval_p_ax0, kval_p_ax1] = wires_direction_b_in[kval_wr_idx_wires ^ 1, kval_p_ax0, kval_p_ax1]
            wires_direction_a_in[kval_wr_idx_wires, kval_p_ax0, kval_p_ax1] = wires_direction_a_in[kval_wr_idx_wires ^ 1, kval_p_ax0, kval_p_ax1]
    for kval_p_ax0 in numba.prange(256):
        for kval_p_ax1 in numba.prange(256):
            connection_inject_from_wires_step(wires_direction_a_out, wires_direction_b_out, wires_spike_a, wires_spike_b, connections_active, connections_spike_in, kval_p_ax0, kval_p_ax1, kval_timestamp, kval_wr_idx, kval_wr_idx_wires, kval_wr_idx_connections)
            update_wires_and_spikes(wires_direction_a_in, wires_direction_a_out, wires_direction_b_in, wires_direction_b_out, wires_spike_a, wires_spike_b, connections_spike_out, connections_active, neurons_active, neurons_spike, trails_next_direction, kval_p_ax0, kval_p_ax1, kval_timestamp, kval_wr_idx, kval_wr_idx_wires, kval_wr_idx_connections, kval_wr_idx_neurons)
    for kval_p_ax0 in numba.prange(256):
        for kval_p_ax1 in numba.prange(256):
            connections_input_direction[kval_wr_idx_connections ^ 1, kval_p_ax0, kval_p_ax1] = connections_input_direction[kval_wr_idx_connections, kval_p_ax0, kval_p_ax1]
            connections_weight[kval_wr_idx_connections ^ 1, kval_p_ax0, kval_p_ax1] = connections_weight[kval_wr_idx_connections, kval_p_ax0, kval_p_ax1]
            connections_spike_out[kval_wr_idx_connections ^ 1, kval_p_ax0, kval_p_ax1] = connections_spike_out[kval_wr_idx_connections, kval_p_ax0, kval_p_ax1]
            connections_spike_in[kval_wr_idx_connections ^ 1, kval_p_ax0, kval_p_ax1] = connections_spike_in[kval_wr_idx_connections, kval_p_ax0, kval_p_ax1]
            connections_active[kval_wr_idx_connections ^ 1, kval_p_ax0, kval_p_ax1] = connections_active[kval_wr_idx_connections, kval_p_ax0, kval_p_ax1]
            connections_neuron_dy[kval_wr_idx_connections ^ 1, kval_p_ax0, kval_p_ax1] = connections_neuron_dy[kval_wr_idx_connections, kval_p_ax0, kval_p_ax1]
            connections_neuron_dx[kval_wr_idx_connections ^ 1, kval_p_ax0, kval_p_ax1] = connections_neuron_dx[kval_wr_idx_connections, kval_p_ax0, kval_p_ax1]
            wires_direction_a_out[kval_wr_idx_wires ^ 1, kval_p_ax0, kval_p_ax1] = wires_direction_a_out[kval_wr_idx_wires, kval_p_ax0, kval_p_ax1]
            wires_direction_b_in[kval_wr_idx_wires ^ 1, kval_p_ax0, kval_p_ax1] = wires_direction_b_in[kval_wr_idx_wires, kval_p_ax0, kval_p_ax1]
            wires_direction_a_in[kval_wr_idx_wires ^ 1, kval_p_ax0, kval_p_ax1] = wires_direction_a_in[kval_wr_idx_wires, kval_p_ax0, kval_p_ax1]
            wires_spike_a[kval_wr_idx_wires ^ 1, kval_p_ax0, kval_p_ax1] = wires_spike_a[kval_wr_idx_wires, kval_p_ax0, kval_p_ax1]
            wires_direction_b_out[kval_wr_idx_wires ^ 1, kval_p_ax0, kval_p_ax1] = wires_direction_b_out[kval_wr_idx_wires, kval_p_ax0, kval_p_ax1]
            wires_spike_b[kval_wr_idx_wires ^ 1, kval_p_ax0, kval_p_ax1] = wires_spike_b[kval_wr_idx_wires, kval_p_ax0, kval_p_ax1]
    kval_wr_idx_connections ^= 1
    for kval_p_ax0 in numba.prange(256):
        for kval_p_ax1 in numba.prange(256):
            neurons_spike[kval_wr_idx_neurons ^ 1, kval_p_ax0, kval_p_ax1] = neurons_spike[kval_wr_idx_neurons, kval_p_ax0, kval_p_ax1]
            neurons_active[kval_wr_idx_neurons ^ 1, kval_p_ax0, kval_p_ax1] = neurons_active[kval_wr_idx_neurons, kval_p_ax0, kval_p_ax1]
            chemicals_excitant[kval_wr_idx_chemicals, kval_p_ax0, kval_p_ax1] = chemicals_excitant[kval_wr_idx_chemicals ^ 1, kval_p_ax0, kval_p_ax1]
    for kval_p_ax0 in numba.prange(256):
        for kval_p_ax1 in numba.prange(256):
            connections_input_direction[kval_wr_idx_connections ^ 1, kval_p_ax0, kval_p_ax1] = connections_input_direction[kval_wr_idx_connections, kval_p_ax0, kval_p_ax1]
            neuron_receive_step(neurons_active, neurons_charge, neurons_spike, neurons_refractory_timer, connections_neuron_dx, connections_neuron_dy, connections_active, connections_weight, connections_spike_in, chemicals_excitant, kval_p_ax0, kval_p_ax1, kval_timestamp, kval_wr_idx, kval_wr_idx_neurons, kval_wr_idx_connections, kval_wr_idx_chemicals)
    for kval_p_ax0 in numba.prange(256):
        for kval_p_ax1 in numba.prange(256):
            neurons_first_connection_y[kval_wr_idx_neurons ^ 1, kval_p_ax0, kval_p_ax1] = neurons_first_connection_y[kval_wr_idx_neurons, kval_p_ax0, kval_p_ax1]
            neurons_refractory_timer[kval_wr_idx_neurons ^ 1, kval_p_ax0, kval_p_ax1] = neurons_refractory_timer[kval_wr_idx_neurons, kval_p_ax0, kval_p_ax1]
            neurons_first_connection_x[kval_wr_idx_neurons ^ 1, kval_p_ax0, kval_p_ax1] = neurons_first_connection_x[kval_wr_idx_neurons, kval_p_ax0, kval_p_ax1]
            neurons_charge[kval_wr_idx_neurons ^ 1, kval_p_ax0, kval_p_ax1] = neurons_charge[kval_wr_idx_neurons, kval_p_ax0, kval_p_ax1]
            connections_spike_in[kval_wr_idx_connections ^ 1, kval_p_ax0, kval_p_ax1] = connections_spike_in[kval_wr_idx_connections, kval_p_ax0, kval_p_ax1]
    kval_wr_idx_neurons ^= 1
    kval_wr_idx_wires ^= 1
    for kval_p_ax0 in numba.prange(256):
        for kval_p_ax1 in numba.prange(256):
            chemicals_excitant[kval_wr_idx_chemicals ^ 1, kval_p_ax0, kval_p_ax1] = chemicals_excitant[kval_wr_idx_chemicals, kval_p_ax0, kval_p_ax1]
            leaders_resolved_next_owner[kval_wr_idx_leaders, kval_p_ax0, kval_p_ax1] = leaders_resolved_next_owner[kval_wr_idx_leaders ^ 1, kval_p_ax0, kval_p_ax1]
            leaders_channel[kval_wr_idx_leaders, kval_p_ax0, kval_p_ax1] = leaders_channel[kval_wr_idx_leaders ^ 1, kval_p_ax0, kval_p_ax1]
            leaders_steps_left[kval_wr_idx_leaders, kval_p_ax0, kval_p_ax1] = leaders_steps_left[kval_wr_idx_leaders ^ 1, kval_p_ax0, kval_p_ax1]
            leaders_intent_next_direction[kval_wr_idx_leaders, kval_p_ax0, kval_p_ax1] = leaders_intent_next_direction[kval_wr_idx_leaders ^ 1, kval_p_ax0, kval_p_ax1]
            trails_channel[kval_wr_idx, kval_p_ax0, kval_p_ax1] = trails_channel[kval_wr_idx ^ 1, kval_p_ax0, kval_p_ax1]
            chemicals_neuro_presence[kval_wr_idx_chemicals, kval_p_ax0, kval_p_ax1] = chemicals_neuro_presence[kval_wr_idx_chemicals ^ 1, kval_p_ax0, kval_p_ax1]
    for kval_p_ax0 in numba.prange(256):
        for kval_p_ax1 in numba.prange(256):
            neurons_first_connection_x[kval_wr_idx_neurons ^ 1, kval_p_ax0, kval_p_ax1] = neurons_first_connection_x[kval_wr_idx_neurons, kval_p_ax0, kval_p_ax1]
            neurons_first_connection_y[kval_wr_idx_neurons ^ 1, kval_p_ax0, kval_p_ax1] = neurons_first_connection_y[kval_wr_idx_neurons, kval_p_ax0, kval_p_ax1]
            neurons_charge[kval_wr_idx_neurons ^ 1, kval_p_ax0, kval_p_ax1] = neurons_charge[kval_wr_idx_neurons, kval_p_ax0, kval_p_ax1]
            wires_spike_a[kval_wr_idx_wires ^ 1, kval_p_ax0, kval_p_ax1] = wires_spike_a[kval_wr_idx_wires, kval_p_ax0, kval_p_ax1]
            wires_spike_b[kval_wr_idx_wires ^ 1, kval_p_ax0, kval_p_ax1] = wires_spike_b[kval_wr_idx_wires, kval_p_ax0, kval_p_ax1]
            connection_convey_step(connections_neuron_dx, connections_neuron_dy, connections_spike_out, connections_active, neurons_spike, kval_p_ax0, kval_p_ax1, kval_timestamp, kval_wr_idx, kval_wr_idx_connections, kval_wr_idx_neurons)
            neuron_update_step(neurons_active, neurons_refractory_timer, chemicals_neuro_presence, leaders_channel, leaders_intent_next_direction, leaders_steps_left, kval_p_ax0, kval_p_ax1, kval_timestamp, kval_wr_idx, kval_wr_idx_neurons, kval_wr_idx_chemicals, kval_wr_idx_leaders)
            leaders_move_step(leaders_channel, leaders_intent_next_direction, leaders_resolved_next_owner, leaders_steps_left, trails_channel, trails_next_direction, trails_prev_direction, connections_neuron_dx, connections_neuron_dy, connections_active, connections_weight, chemicals_neuro_presence, neurons_active, kval_p_ax0, kval_p_ax1, kval_timestamp, kval_wr_idx, kval_wr_idx_leaders, kval_wr_idx_connections, kval_wr_idx_chemicals, kval_wr_idx_neurons)
            trails_update_step(trails_channel, trails_next_direction, trails_prev_direction, leaders_channel, connections_active, wires_direction_a_in, wires_direction_a_out, wires_direction_b_in, wires_direction_b_out, kval_p_ax0, kval_p_ax1, kval_timestamp, kval_wr_idx, kval_wr_idx_leaders, kval_wr_idx_connections, kval_wr_idx_wires)
    for kval_p_ax0 in numba.prange(256):
        for kval_p_ax1 in numba.prange(256):
            leaders_resolved_next_owner[kval_wr_idx_leaders ^ 1, kval_p_ax0, kval_p_ax1] = leaders_resolved_next_owner[kval_wr_idx_leaders, kval_p_ax0, kval_p_ax1]
            leaders_channel[kval_wr_idx_leaders ^ 1, kval_p_ax0, kval_p_ax1] = leaders_channel[kval_wr_idx_leaders, kval_p_ax0, kval_p_ax1]
            leaders_steps_left[kval_wr_idx_leaders ^ 1, kval_p_ax0, kval_p_ax1] = leaders_steps_left[kval_wr_idx_leaders, kval_p_ax0, kval_p_ax1]
            leaders_intent_next_direction[kval_wr_idx_leaders ^ 1, kval_p_ax0, kval_p_ax1] = leaders_intent_next_direction[kval_wr_idx_leaders, kval_p_ax0, kval_p_ax1]
            trails_prev_direction[kval_wr_idx ^ 1, kval_p_ax0, kval_p_ax1] = trails_prev_direction[kval_wr_idx, kval_p_ax0, kval_p_ax1]
            trails_next_direction[kval_wr_idx ^ 1, kval_p_ax0, kval_p_ax1] = trails_next_direction[kval_wr_idx, kval_p_ax0, kval_p_ax1]
            chemicals_neuro_presence[kval_wr_idx_chemicals ^ 1, kval_p_ax0, kval_p_ax1] = chemicals_neuro_presence[kval_wr_idx_chemicals, kval_p_ax0, kval_p_ax1]
            neurons_spike[kval_wr_idx_neurons ^ 1, kval_p_ax0, kval_p_ax1] = neurons_spike[kval_wr_idx_neurons, kval_p_ax0, kval_p_ax1]
            neurons_active[kval_wr_idx_neurons ^ 1, kval_p_ax0, kval_p_ax1] = neurons_active[kval_wr_idx_neurons, kval_p_ax0, kval_p_ax1]
            neurons_refractory_timer[kval_wr_idx_neurons ^ 1, kval_p_ax0, kval_p_ax1] = neurons_refractory_timer[kval_wr_idx_neurons, kval_p_ax0, kval_p_ax1]
            connections_spike_out[kval_wr_idx_connections ^ 1, kval_p_ax0, kval_p_ax1] = connections_spike_out[kval_wr_idx_connections, kval_p_ax0, kval_p_ax1]
            connections_active[kval_wr_idx_connections ^ 1, kval_p_ax0, kval_p_ax1] = connections_active[kval_wr_idx_connections, kval_p_ax0, kval_p_ax1]
            connections_neuron_dx[kval_wr_idx_connections ^ 1, kval_p_ax0, kval_p_ax1] = connections_neuron_dx[kval_wr_idx_connections, kval_p_ax0, kval_p_ax1]
            connections_weight[kval_wr_idx_connections ^ 1, kval_p_ax0, kval_p_ax1] = connections_weight[kval_wr_idx_connections, kval_p_ax0, kval_p_ax1]
            connections_neuron_dy[kval_wr_idx_connections ^ 1, kval_p_ax0, kval_p_ax1] = connections_neuron_dy[kval_wr_idx_connections, kval_p_ax0, kval_p_ax1]
            wires_direction_a_out[kval_wr_idx_wires ^ 1, kval_p_ax0, kval_p_ax1] = wires_direction_a_out[kval_wr_idx_wires, kval_p_ax0, kval_p_ax1]
            wires_direction_b_out[kval_wr_idx_wires ^ 1, kval_p_ax0, kval_p_ax1] = wires_direction_b_out[kval_wr_idx_wires, kval_p_ax0, kval_p_ax1]
    kval_wr_idx_leaders ^= 1
    kval_wr_idx_chemicals ^= 1
    for kval_p_ax0 in numba.prange(256):
        for kval_p_ax1 in numba.prange(256):
            chemicals_update_step(chemicals_excitant, chemicals_neuro_presence, kval_p_ax0, kval_p_ax1, kval_timestamp, kval_wr_idx, kval_wr_idx_chemicals)
            leader_claims_update_step(leaders_channel, leaders_intent_next_direction, leaders_resolved_next_owner, leaders_steps_left, trails_channel, wires_direction_a_in, wires_direction_b_in, kval_p_ax0, kval_p_ax1, kval_timestamp, kval_wr_idx, kval_wr_idx_leaders, kval_wr_idx_wires)
    kval_wr_idx ^= 1
    kval_wr_idx_neurons ^= 1
    kval_wr_idx_leaders ^= 1
    kval_wr_idx_chemicals ^= 1
    kval_wr_idx_wires ^= 1
    kval_wr_idx_connections ^= 1
    return (kval_wr_idx, kval_wr_idx_neurons, kval_wr_idx_leaders, kval_wr_idx_chemicals, kval_wr_idx_wires, kval_wr_idx_connections)