def connection_inject_from_wires_step(wires_direction_a_out, wires_direction_b_out, wires_spike_a, wires_spike_b, connections_active, connections_spike_in, kval_p_ax0, kval_p_ax1, kval_timestamp, kval_wr_idx, kval_wr_idx_wires, kval_wr_idx_connections, /):
    """Seed connection.spike_in when an adjacent wire outputs into this cell."""
    x, y = (kval_p_ax0, kval_p_ax1)
    if connections_active[1 ^ kval_wr_idx_connections, x, y] == 0:
        connections_spike_in[kval_wr_idx_connections, x, y] = 0
        return
    hit = 0
    for i in range(8):
        d = np.uint8(1 << i)
        dx, dy = direction_to_vec(d)
        nx, ny = ((x + dx) % 256, (y + dy) % 256)
        want = rotate_direction(d, 4)
        if wires_direction_a_out[1 ^ kval_wr_idx_wires, nx, ny] == want and wires_spike_a[1 ^ kval_wr_idx_wires, nx, ny] != 0:
            hit = 1
            break
        if wires_direction_b_out[1 ^ kval_wr_idx_wires, nx, ny] == want and wires_spike_b[1 ^ kval_wr_idx_wires, nx, ny] != 0:
            hit = 1
            break
    connections_spike_in[kval_wr_idx_connections, x, y] = np.uint8(hit)