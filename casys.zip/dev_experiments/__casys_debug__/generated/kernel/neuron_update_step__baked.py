def neuron_update_step(neurons_active, neurons_refractory_timer, chemicals_neuro_presence, leaders_channel, leaders_intent_next_direction, leaders_steps_left, kval_p_ax0, kval_p_ax1, kval_timestamp, kval_wr_idx, kval_wr_idx_neurons, kval_wr_idx_chemicals, kval_wr_idx_leaders, /):
    x, y = (kval_p_ax0, kval_p_ax1)
    timestamp = kval_timestamp
    if neurons_active[1 ^ kval_wr_idx_neurons, x, y] == 0:
        return
    refractory_timer = neurons_refractory_timer[1 ^ kval_wr_idx_neurons, x, y]
    if refractory_timer:
        neurons_refractory_timer[kval_wr_idx_neurons, x, y] = refractory_timer - 1
    rng_seed = rng_hash(x, y, timestamp)
    chemicals_neuro_presence[kval_wr_idx_chemicals, x, y] = 1.0
    if rng_int(rng_seed, 0, 100) == 0:
        rng_seed = rng_chain(rng_seed)
        leaders_channel[kval_wr_idx_leaders, x, y] = rng_int(rng_seed, 0, 255)
        rng_seed = rng_chain(rng_seed)
        leaders_intent_next_direction[kval_wr_idx_leaders, x, y] = 1 << rng_int(rng_seed, 0, 7)
        rng_seed = rng_chain(rng_seed)
        leaders_steps_left[kval_wr_idx_leaders, x, y] = 15 + np.uint16(rng_int(rng_seed, 0, 50))