def connection_convey_step(connections_neuron_dx, connections_neuron_dy, connections_spike_out, connections_active, neurons_spike, kval_p_ax0, kval_p_ax1, kval_timestamp, kval_wr_idx, kval_wr_idx_connections, kval_wr_idx_neurons, /):
    """
    Move spike_in one cell closer to the neuron using the per-cell vector field.
    One hop per tick, no extra delay logic.
    """
    x, y = (kval_p_ax0, kval_p_ax1)
    if connections_active[1 ^ kval_wr_idx_connections, x, y] == 0:
        return
    nx, ny = ((x + connections_neuron_dx[1 ^ kval_wr_idx_connections, kval_p_ax0, kval_p_ax1]) % 256, (y + connections_neuron_dy[1 ^ kval_wr_idx_connections, kval_p_ax0, kval_p_ax1]) % 256)
    connections_spike_out[kval_wr_idx_connections, x, y] = neurons_spike[1 ^ kval_wr_idx_neurons, nx, ny]