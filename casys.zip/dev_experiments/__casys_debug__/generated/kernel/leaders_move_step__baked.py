def leaders_move_step(leaders_channel, leaders_intent_next_direction, leaders_resolved_next_owner, leaders_steps_left, trails_channel, trails_next_direction, trails_prev_direction, connections_neuron_dx, connections_neuron_dy, connections_active, connections_weight, chemicals_neuro_presence, neurons_active, kval_p_ax0, kval_p_ax1, kval_timestamp, kval_wr_idx, kval_wr_idx_leaders, kval_wr_idx_connections, kval_wr_idx_chemicals, kval_wr_idx_neurons, /):
    timestamp = kval_timestamp
    x, y = (kval_p_ax0, kval_p_ax1)
    channel = leaders_channel[1 ^ kval_wr_idx_leaders, kval_p_ax0, kval_p_ax1]
    next_owner_dir = leaders_resolved_next_owner[1 ^ kval_wr_idx_leaders, kval_p_ax0, kval_p_ax1]
    if channel == 0 and next_owner_dir == 0:
        return
    rng_seed = rng_hash(x, y, timestamp)
    channel = leaders_channel[1 ^ kval_wr_idx_leaders, kval_p_ax0, kval_p_ax1]
    neuro_presence = chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x, y]
    if channel != 0:
        steps_left = leaders_steps_left[1 ^ kval_wr_idx_leaders, kval_p_ax0, kval_p_ax1]
        if steps_left > 0:
            steps_left = leaders_steps_left[1 ^ kval_wr_idx_leaders, kval_p_ax0, kval_p_ax1] - 1
            next_direction = leaders_intent_next_direction[1 ^ kval_wr_idx_leaders, kval_p_ax0, kval_p_ax1]
            dx, dy = direction_to_vec(next_direction)
            nx, ny = ((x + dx) % 256, (y + dy) % 256)
            if leaders_resolved_next_owner[1 ^ kval_wr_idx_leaders, nx, ny] != rotate_direction(next_direction, 4):
                next_direction = 1 << np.uint8(rng_int(rng_seed, 0, 7))
                leaders_intent_next_direction[kval_wr_idx_leaders, x, y] = next_direction
                leaders_steps_left[kval_wr_idx_leaders, x, y] = steps_left
                trails_channel[kval_wr_idx, kval_p_ax0, kval_p_ax1] = channel
                trails_next_direction[kval_wr_idx, x, y] = next_direction
                return
            trails_channel[kval_wr_idx, kval_p_ax0, kval_p_ax1] = channel
            trails_next_direction[kval_wr_idx, x, y] = next_direction
            neurons_check = bool(neurons_active[1 ^ kval_wr_idx_neurons, nx, ny])
            connections_check = bool(connections_active[1 ^ kval_wr_idx_connections, nx, ny])
            if neurons_check or connections_check:
                connections_active[kval_wr_idx_connections, x, y] = 1
                connections_weight[kval_wr_idx_connections, x, y] = 0.1
                if neurons_check:
                    connections_neuron_dx[kval_wr_idx_connections, x, y] = dx
                    connections_neuron_dy[kval_wr_idx_connections, x, y] = dy
                else:
                    connections_neuron_dx[kval_wr_idx_connections, x, y] = connections_neuron_dx[1 ^ kval_wr_idx_connections, nx, ny] - dx
                    connections_neuron_dy[kval_wr_idx_connections, x, y] = connections_neuron_dy[1 ^ kval_wr_idx_connections, nx, ny] - dy
        elif next_owner_dir == 0:
            leaders_channel[kval_wr_idx_leaders, x, y] = 0
            leaders_intent_next_direction[kval_wr_idx_leaders, x, y] = 0
            rng_seed = rng_chain(rng_seed)
            if rng_int(rng_seed, 0, 25) > 100 * neuro_presence:
                neurons_active[kval_wr_idx_neurons, x, y] = 1
            return
    if next_owner_dir:
        no_dx, no_dy = direction_to_vec(next_owner_dir)
        no_x, no_y = ((x + no_dx) % 256, (y + no_dy) % 256)
        new_steps_left = leaders_steps_left[1 ^ kval_wr_idx_leaders, no_x, no_y]
        if new_steps_left > 0:
            new_steps_left -= 1
            c_avg = (chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x + -1, y + -1] + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x, y + -1] + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x + 1, y + -1] + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x + -1, y] + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x, y] + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x + 1, y] + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x + -1, y + 1] + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x, y + 1] + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x + 1, y + 1] if 1 < x < 256 - 1 and 1 < y < 256 - 1 else chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, (x + -1) % 256, (y + -1) % 256] + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x, (y + -1) % 256] + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, (x + 1) % 256, (y + -1) % 256] + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, (x + -1) % 256, y] + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x, y] + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, (x + 1) % 256, y] + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, (x + -1) % 256, (y + 1) % 256] + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x, (y + 1) % 256] + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, (x + 1) % 256, (y + 1) % 256]) / 9
            eps = 1e-06
            gx = chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x + -1, y + -1] * -1 + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x + 1, y + -1] + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x + -1, y] * -2 + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x + 1, y] * 2 + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x + -1, y + 1] * -1 + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x + 1, y + 1] if 1 < x < 256 - 1 and 1 < y < 256 - 1 else chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, (x + -1) % 256, (y + -1) % 256] * -1 + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, (x + 1) % 256, (y + -1) % 256] + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, (x + -1) % 256, y] * -2 + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, (x + 1) % 256, y] * 2 + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, (x + -1) % 256, (y + 1) % 256] * -1 + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, (x + 1) % 256, (y + 1) % 256]
            gy = chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x + -1, y + -1] * -1 + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x, y + -1] * -2 + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x + 1, y + -1] * -1 + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x + -1, y + 1] + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x, y + 1] * 2 + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x + 1, y + 1] if 1 < x < 256 - 1 and 1 < y < 256 - 1 else chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, (x + -1) % 256, (y + -1) % 256] * -1 + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x, (y + -1) % 256] * -2 + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, (x + 1) % 256, (y + -1) % 256] * -1 + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, (x + -1) % 256, (y + 1) % 256] + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, x, (y + 1) % 256] * 2 + chemicals_neuro_presence[1 ^ kval_wr_idx_chemicals, (x + 1) % 256, (y + 1) % 256]
            g = np.sqrt(gx * gx + gy * gy)
            fwd_dir = rotate_direction(next_owner_dir, 4)
            vx, vy = direction_to_vec(fwd_dir)
            align = (gx * vx + gy * vy) / (g + eps)
            s = 1.0 if align >= 0.0 else -1.0
            drift_dx = s * gx
            drift_dy = s * gy
            wg = g / (g + 0.2)
            wc = c_avg / (c_avg + 0.05)
            p_drift = clamp01(0.75 * wg + (1.0 - 0.75) * wc)
            rng_seed = rng_chain(rng_seed)
            pick = rng_int(rng_seed, 0, 1023)
            if pick < int(p_drift * 1023.0):
                new_direction = dir8_from_vec(drift_dx, drift_dy)
            else:
                rng_seed = rng_chain(rng_seed)
                offset = rng_int(rng_seed, -1, 1)
                new_direction = rotate_direction(fwd_dir, offset)
            leaders_intent_next_direction[kval_wr_idx_leaders, x, y] = new_direction
            trails_next_direction[kval_wr_idx, x, y] = new_direction
        new_channel = leaders_channel[1 ^ kval_wr_idx_leaders, no_x, no_y]
        leaders_channel[kval_wr_idx_leaders, x, y] = new_channel
        leaders_steps_left[kval_wr_idx_leaders, x, y] = new_steps_left
        trails_channel[kval_wr_idx, x, y] = new_channel
        trails_prev_direction[kval_wr_idx, x, y] = next_owner_dir
    else:
        leaders_channel[kval_wr_idx_leaders, x, y] = 0
        leaders_intent_next_direction[kval_wr_idx_leaders, x, y] = 0
        leaders_steps_left[kval_wr_idx_leaders, x, y] = 0