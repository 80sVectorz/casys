def neuron_receive_step(neurons_active, neurons_charge, neurons_spike, neurons_refractory_timer, connections_neuron_dx, connections_neuron_dy, connections_active, connections_weight, connections_spike_in, chemicals_excitant, kval_p_ax0, kval_p_ax1, kval_timestamp, kval_wr_idx, kval_wr_idx_neurons, kval_wr_idx_connections, kval_wr_idx_chemicals, /):
    """
    Sum weighted spikes from connection cells in a small halo around the soma.
    This allows fan-in >> 8 in a single tick.
    """
    x, y = (kval_p_ax0, kval_p_ax1)
    if neurons_active[1 ^ kval_wr_idx_neurons, x, y] == 0:
        return
    acc = neurons_charge[1 ^ kval_wr_idx_neurons, x, y] * 0.999
    excitant_levels = chemicals_excitant[1 ^ kval_wr_idx_chemicals, x, y]
    if excitant_levels:
        rng_seed = rng_hash(x, y, kval_timestamp)
        if rng_int(rng_seed, 0, 100) < excitant_levels * 100:
            acc += 0.05
    R = 2
    for oy in range(-R, R + 1):
        for ox in range(-R, R + 1):
            if ox == 0 and oy == 0:
                continue
            nx, ny = ((x + ox) % 256, (y + oy) % 256)
            if connections_active[1 ^ kval_wr_idx_connections, nx, ny] == 0:
                continue
            if connections_spike_in[1 ^ kval_wr_idx_connections, nx, ny] != 0 and nx + connections_neuron_dx[1 ^ kval_wr_idx_connections, nx, ny] == x and (ny + connections_neuron_dy[1 ^ kval_wr_idx_connections, nx, ny] == y):
                w = float(connections_weight[1 ^ kval_wr_idx_connections, nx, ny])
                acc += w
    neurons_charge[kval_wr_idx_neurons, x, y] = acc
    if acc > 1 and (not neurons_refractory_timer[1 ^ kval_wr_idx_neurons, x, y]):
        neurons_charge[kval_wr_idx_neurons, x, y] = 0
        neurons_spike[kval_wr_idx_neurons, x, y] = 1
        neurons_refractory_timer[kval_wr_idx_neurons, x, y] = 100