def wires_update_step(wires_direction_a_in, wires_direction_a_out, wires_direction_b_in, wires_direction_b_out, wires_spike_a, wires_spike_b, connections_spike_out, connections_active, neurons_active, neurons_spike, trails_next_direction, kval_p_ax0, kval_p_ax1, kval_timestamp, kval_wr_idx, kval_wr_idx_wires, kval_wr_idx_connections, /):
    x, y = (kval_p_ax0, kval_p_ax1)
    connections_spike_out[kval_wr_idx_connections, x, y] = 0
    wires_spike_a[kval_wr_idx_wires, x, y] = 0
    wires_spike_b[kval_wr_idx_wires, x, y] = 0
    d_a_in = wires_direction_a_in[1 ^ kval_wr_idx_wires, x, y]
    d_b_in = wires_direction_b_in[1 ^ kval_wr_idx_wires, x, y]
    d_a_out = wires_direction_a_out[1 ^ kval_wr_idx_wires, x, y]
    d_b_out = wires_direction_b_out[1 ^ kval_wr_idx_wires, x, y]
    if d_a_in | d_a_out | d_b_in | d_b_out == 0:
        return
    dc_x, dc_y = (x, y)
    if d_a_in != 0:
        dc_dx, dc_dy = direction_to_vec(d_a_in)
        dc_x, dc_y = ((x + dc_dx) % 256, (y + dc_dy) % 256)
        connection_spike = connections_spike_out[1 ^ kval_wr_idx_connections, dc_x, dc_y] | neurons_spike[1 ^ kval_wr_idx, dc_x, dc_y] & connections_active[1 ^ kval_wr_idx_connections, dc_x, dc_y]
        if connection_spike:
            wires_spike_a[kval_wr_idx_wires, x, y] = 1
        elif wires_direction_a_out[1 ^ kval_wr_idx_wires, dc_x, dc_y] | wires_direction_b_out[1 ^ kval_wr_idx_wires, dc_x, dc_y] | connections_active[1 ^ kval_wr_idx_connections, dc_x, dc_y] != 0:
            neighbor_spike_a = wires_spike_a[1 ^ kval_wr_idx_wires, dc_x, dc_y]
            neighbor_spike_b = wires_spike_b[1 ^ kval_wr_idx_wires, dc_x, dc_y]
            spike_check = (wires_direction_a_out[1 ^ kval_wr_idx_wires, dc_x, dc_y] * neighbor_spike_a | wires_direction_b_out[1 ^ kval_wr_idx_wires, dc_x, dc_y] * neighbor_spike_b) & rotate_direction(d_a_in, 4)
            wires_spike_a[kval_wr_idx_wires, x, y] = spike_check != 0
        elif connections_active[1 ^ kval_wr_idx_connections, dc_x, dc_y] | neurons_active[1 ^ kval_wr_idx, dc_x, dc_y] == 0 and trails_next_direction[1 ^ kval_wr_idx, dc_x, dc_y] != rotate_direction(d_a_in, 4):
            wires_direction_a_in[kval_wr_idx_wires, x, y] = 0
            wires_direction_a_out[kval_wr_idx_wires, x, y] = 0
    if d_b_in != 0:
        dc_dx, dc_dy = direction_to_vec(d_b_in)
        dc_x, dc_y = ((x + dc_dx) % 256, (y + dc_dy) % 256)
        connection_spike = connections_spike_out[1 ^ kval_wr_idx_connections, dc_x, dc_y] | neurons_spike[1 ^ kval_wr_idx, dc_x, dc_y] & connections_active[1 ^ kval_wr_idx_connections, dc_x, dc_y]
        if connection_spike:
            wires_spike_b[kval_wr_idx_wires, x, y] = 1
        elif wires_direction_a_out[1 ^ kval_wr_idx_wires, dc_x, dc_y] | wires_direction_b_out[1 ^ kval_wr_idx_wires, dc_x, dc_y] | connections_active[1 ^ kval_wr_idx_connections, dc_x, dc_y] != 0:
            neighbor_spike_a = wires_spike_a[1 ^ kval_wr_idx_wires, dc_x, dc_y]
            neighbor_spike_b = wires_spike_b[1 ^ kval_wr_idx_wires, dc_x, dc_y]
            spike_check = (wires_direction_a_out[1 ^ kval_wr_idx_wires, dc_x, dc_y] * neighbor_spike_a | wires_direction_b_out[1 ^ kval_wr_idx_wires, dc_x, dc_y] * neighbor_spike_b) & rotate_direction(d_b_in, 4)
            wires_spike_b[kval_wr_idx_wires, x, y] = spike_check != 0
        elif connections_active[1 ^ kval_wr_idx_connections, dc_x, dc_y] | neurons_active[1 ^ kval_wr_idx, dc_x, dc_y] == 0 and trails_next_direction[1 ^ kval_wr_idx, dc_x, dc_y] != rotate_direction(d_b_in, 4):
            wires_direction_b_in[kval_wr_idx_wires, x, y] = 0
            wires_direction_b_out[kval_wr_idx_wires, x, y] = 0