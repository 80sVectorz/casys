def connection_update_step(connections_spike, connections_active, kval_p_ax0, kval_p_ax1, kval_timestamp, kval_wr_idx, /):
    x, y = (kval_p_ax0, kval_p_ax1)
    if connections_active[1 ^ kval_wr_idx, x, y] == 0:
        return
    rng_seed = rng_hash(x, y, kval_timestamp)
    if rng_int(rng_seed, 0, 10) == 0:
        connections_spike[kval_wr_idx, x, y] = 1