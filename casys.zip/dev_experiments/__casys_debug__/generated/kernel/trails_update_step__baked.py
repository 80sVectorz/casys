def trails_update_step(trails_channel, trails_next_direction, trails_prev_direction, leaders_channel, connections_active, wires_direction_a_in, wires_direction_a_out, wires_direction_b_in, wires_direction_b_out, kval_p_ax0, kval_p_ax1, kval_timestamp, kval_wr_idx, kval_wr_idx_leaders, kval_wr_idx_connections, kval_wr_idx_wires, /):
    x, y = (kval_p_ax0, kval_p_ax1)
    channel = trails_channel[1 ^ kval_wr_idx, x, y]
    next_direction = trails_next_direction[1 ^ kval_wr_idx, x, y]
    if channel | next_direction == 0:
        return
    next_direction_flipped = rotate_direction(next_direction, 4)
    n_dx, n_dy = direction_to_vec(next_direction)
    nx, ny = ((x + n_dx) % 256, (y + n_dy) % 256)
    prev_direction = trails_prev_direction[1 ^ kval_wr_idx, x, y]
    if not (trails_channel[1 ^ kval_wr_idx, nx, ny] == channel and trails_prev_direction[1 ^ kval_wr_idx, nx, ny] == next_direction_flipped) and leaders_channel[1 ^ kval_wr_idx_leaders, x, y] != channel and (leaders_channel[1 ^ kval_wr_idx_leaders, nx, ny] != channel):
        if connections_active[1 ^ kval_wr_idx_connections, nx, ny] != 0 or (wires_direction_a_in[1 ^ kval_wr_idx_wires, nx, ny] | wires_direction_b_in[1 ^ kval_wr_idx_wires, nx, ny]) & next_direction_flipped != 0:
            if wires_direction_a_in[1 ^ kval_wr_idx_wires, x, y] == 0:
                wires_direction_a_in[kval_wr_idx_wires, x, y] = prev_direction
                wires_direction_a_out[kval_wr_idx_wires, x, y] = next_direction
            elif wires_direction_b_in[1 ^ kval_wr_idx_wires, x, y] == 0:
                wires_direction_b_in[kval_wr_idx_wires, x, y] = prev_direction
                wires_direction_b_out[kval_wr_idx_wires, x, y] = next_direction
        trails_channel[kval_wr_idx, x, y] = 0
        trails_next_direction[kval_wr_idx, x, y] = 0
        trails_prev_direction[kval_wr_idx, x, y] = 0
        return